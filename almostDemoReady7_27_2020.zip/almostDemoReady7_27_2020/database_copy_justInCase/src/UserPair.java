import java.util.ArrayList;

import java.util.*;

public class UserPair {
	
	// Data
	protected People user1;
	protected People user2;
	protected List<Integer> comids;
	
	
	// Default Constructor
	public UserPair() {
		user1 = new People();
		user2 = new People();
		//List<Integer> comids = new ArrayList<Integer>();
	}
	
	// Arg Constructor
	public UserPair(People u1, People u2, List<Integer> fav) {
		this.user1 = u1;
		this.user2 = u2;
		this.comids = fav;
	}
	
	// Getters & Setters
	public People getUser1() {
		return user1;
	}

	public void setUser1(People user1) {
		this.user1 = user1;
	}

	public People getUser2() {
		return user2;
	}

	public void setUser2(People user2) {
		this.user2 = user2;
	}

	public List<Integer> getComids() {
		return comids;
	}

	public void setComids(List<Integer> favorite) {
		this.comids = favorite;
	}

	// Methods
	public boolean containsUser(People u1){
		
		if(user1.getEmail().equals(u1.getEmail()) || user2.getEmail().equals(u1.getEmail())){
			return true;
		}
		else {
			return false;
		}
		
	}
	
	public boolean containsUsers(People u1, People u2) {
		
		if(this.containsUser(u1)) {
			
			if(this.containsUser(u2)) {
				return true;
			}
			else {
				return false;
			}
			
			
		}
		else if(this.containsUser(u2)) {
			
			if(this.containsUser(u1)) {
				return true;
			}
			else {
				return false;
			}
			
		}
		else {
			return false;
		}
		
		
	}
}
