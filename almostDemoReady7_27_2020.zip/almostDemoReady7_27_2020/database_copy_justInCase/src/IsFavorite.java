
public class IsFavorite {
	
	protected String email;
	protected int comid;

	IsFavorite(){
		
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getComid() {
		return comid;
	}

	public void setComid(int comid) {
		this.comid = comid;
	}
	
	
}
