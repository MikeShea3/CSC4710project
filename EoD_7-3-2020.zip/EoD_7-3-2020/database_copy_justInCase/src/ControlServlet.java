import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
 
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
 
import java.sql.SQLIntegrityConstraintViolationException;
/**
 * ControllerServlet.java
 * This servlet acts as a page controller for the application, handling all
 * requests from the user.
 * @author www.codejava.net
 */
public class ControlServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    public PeopleDAO peopleDAO;
 
    public void init() {
        peopleDAO = new PeopleDAO(); 
    }
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();
        System.out.println(action);
        try {
            switch (action) {
            case "/new":
                showNewForm(request, response);
                break;
            case "/insert":
            	insertPeople(request, response);
                break;
            case "/delete":
            	deletePeople(request, response);
                break;
            case "/edit":
                showEditForm(request, response);
                break;
            case "/update":
            	updatePeople(request, response);
                break;
            case "/logout":
            	logout(request, response);
            	break;
            case "/login":
            	login(request, response);
            	break;
            case "/initdb":
            	initdb(request, response);
            	break;
            case "/newVideo":
            	showInsertVideoForm(request,response);
            	break;
            case "/insertVideo":
            	insertVideo(request, response);
            	break;
            case "/showSearchVideos":
            	showSearchVideos(request, response);
            	break;
            case "/searchVideos":
            	searchVideos(request, response);
            	break; 
            case "/home":
            	goHome(request, response);	// works but logs the user out - insecure
            	break;
            case "/ShowVideo":
            	goToVideo(request, response);
            	break;
            case "/insertReview":
            	insertReview(request, response);
            	break;
            case "/deleteReview":
            	//deleteReview(request, response);
            	break;
            case "/insertFavorite":
            	insertFavorite(request, response);
            	break;
            case "/deleteFavorite":
            	deleteFavorite(request, response);
            	break;
            case"/showFavorites":
            	showFavorites(request, response);
            	break;
            default: 
            	listPeople(request, response);
            	break;
            	/* This line used to list people as the default. 
            	 * We want it to function as a login instead because 
            	 * we won't be listing anything in the application
            	 * because the information in sensitive. I changed the
            	 * jsp file to relfect this and now the original
            	 * list all people button says login. If we can get that to work
            	 * by using the verification in PeopleDAO, we should be good.       	
            	 */
               
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }
    
    
    private void showFavorites(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
    	
    	// Get Comedian Info
    	String email = peopleDAO.people.getEmail();
    	List<Integer> comidList = peopleDAO.getComidFromFavorites(email);
    	
    	// TEST
    	System.out.println("email = " + email);
    	System.out.println("COMID LIST");
    	System.out.println("============");
    	for(int i = 0; i < comidList.size(); i++) {
    		System.out.println(comidList.get(i));
    	}
    	
    	// Get Comedian objects
    	List<Comedian> comedianList;
    	comedianList = peopleDAO.getComediansFromComidList(comidList);
    	
    	// TEST
    	System.out.println("COMEDIANS");
    	System.out.println("============");
    	for(int i = 0; i< comedianList.size(); i++) {
    		System.out.println(comedianList.get(i).getFirstname());
    	}
    	

    	
    	
    	
    	// Send Comedian Objects to resource pool
    	request.setAttribute("comedianArray", comedianList);  
    	
    	// Load page with favorites
    	RequestDispatcher dispatcher = request.getRequestDispatcher("favorites.jsp");
        dispatcher.forward(request, response);
    }
    
    
    
    // Method to initialize database
    private void initdb(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
    	
    	peopleDAO.initialize();
    	String destPage;
    	HttpSession session = request.getSession();
        destPage = "root.jsp";
        RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
        dispatcher.forward(request, response);
    
    
    }
    
    
    
    private void goToVideo(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
    	
    	String url = request.getParameter("url");
    	
    	System.out.println("url = " + url);
    	
    	YoutubeVideo currentVideo = peopleDAO.getVideoFromURL(url);
    	
    	// Must be in array to iterate over
    	YoutubeVideo[] currentVideoArray = new YoutubeVideo[1];
    	currentVideoArray[0] = currentVideo;
    	
    	request.setAttribute("currentVideo", currentVideoArray);  
    	RequestDispatcher dispatcher = request.getRequestDispatcher("ShowVideo.jsp");
        dispatcher.forward(request, response);
    }
    
    // Does not work yet
    private void goHome(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	RequestDispatcher dispatcher = request.getRequestDispatcher("home.jsp");
        dispatcher.forward(request, response);
    }
        
        
    // Method to show the search videos page
    private void showSearchVideos(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	RequestDispatcher dispatcher = request.getRequestDispatcher("SearchVideoForm.jsp");
        dispatcher.forward(request, response);
    }
    
    
    // Method to insert a new user to the table [Complete]
    private void showInsertVideoForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("InsertVideoForm.jsp");
        dispatcher.forward(request, response);
    }
    
    private void searchVideos(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
    	
    
    	String input = request.getParameter("video");// Get info from search bar
    	String[] userInput = input.split(", ");	// Array of youtube videos to send to results page
    	List<Comedian> comediansFromInput = new ArrayList<Comedian>();
    	List<YoutubeTag> tagsFromInput = new ArrayList<YoutubeTag>();
    	List<YoutubeVideo> videosFromComedians = new ArrayList<YoutubeVideo>();
    	List<YoutubeVideo> videosFromTags= new ArrayList<YoutubeVideo>();
    	
    	// Get all matching comids (WORKS)
    	comediansFromInput = peopleDAO.getComedianFromInput(userInput); 	// check the user's input if they entered a comedians name and returns the comid
    	videosFromComedians = peopleDAO.relateComidToURL(comediansFromInput);
    	
    	
    	// Get all matching tags (WORKS)
    	tagsFromInput = peopleDAO.getTagsFromInput(userInput);
    	videosFromTags = peopleDAO.relateTagsToURL(tagsFromInput);
    	

    	
    	// Combine Lists
    	List<YoutubeVideo> videoList = new ArrayList<YoutubeVideo>();
    	
    	// Append videosFromComedians
    	for(int i = 0; i < videosFromComedians.size(); i++) {
    		
    		// Check that video is not already in list
    		boolean inList = false;
    		for(int j = 0; j < videoList.size(); j++) {
    			
    			if(videosFromComedians.get(i).getUrl() == videoList.get(j).getUrl()) {
    				inList = true;
    			}
    		
    		}
    		
    		if(inList == false) {
    			videoList.add(videosFromComedians.get(i));
    		}
    		
    	}
    	
    	// Append videosFromTags
    	for(int i = 0; i < videosFromTags.size(); i++) {
    		
    		// Check that video is not already in list
    		boolean inList = false;
    		for(int j = 0; j < videoList.size(); j++) {
    			
    			if(videosFromTags.get(i).getUrl() == videoList.get(j).getUrl()) {
    				inList = true;
    			}
    		
    		}
    		
    		if(inList == false) {
    			videoList.add(videosFromTags.get(i));
    		}
    		
    	}
    	
    	// Send videoList to resources and redirect page
    	request.setAttribute("listVideos", videoList);
        RequestDispatcher dispatcher = request.getRequestDispatcher("ShowSearchResults.jsp");       
        dispatcher.forward(request, response);
    	
    	/*
    	
    	// Search comedians for firstname OR lastname and get comid
    	
    	// Initialize
    	List<Integer> comid = new ArrayList<Integer>();
    	List<YoutubeVideo> videosFromComedians;
    	String input = request.getParameter("video");// Get info from search bar
    	String[] userInput = input.split(", ");	// Array of youtube videos to send to results page
    	
    	// Get all matching comids
    	comid = peopleDAO.getComidFromArray(userInput); 	// check the user's input if they entered a comedians name and returns the comid
    	
    	
    	
    	// Select URLs with matching tag
		List<YoutubeVideo> videosFromTags = peopleDAO.relateTagsToURL(userInput);// return a list of youtubevideo objects
    	
		
    	
    	// TEST
    	System.out.println("input = " +input);
    	for(int i = 0; i <userInput.length; i++) {
    		System.out.println("index " + i + " = " + userInput[i]);
    	}
    	System.out.println("SPLIT STRING:");
    	System.out.println("============");
    	for(int i = 0; i < userInput.length; i++) {
    		System.out.println(i + " " + userInput[i]);
    	}
    	
    		
		// Get Comedian objects
		List<Comedian> comedianList = new ArrayList<Comedian>();
		comedianList = peopleDAO.getComedianFromComid(comid);
    	
		for(int i = 0; i < comedianList.size(); i++) {
			System.out.println("comedian identified: " + comedianList.get(i).getFirstname());
			System.out.println("comid = " + comedianList.get(i).getComid());
		}
		
		// Get videos where comedian exists
		videosFromComedians = peopleDAO.relateComidToURL(comedianList);

	
    	// Concat both lists together
    	List<YoutubeVideo> bothLists = new ArrayList<YoutubeVideo>();
    	for(int i = 0; i < videosFromComedians.size(); i++) {
    		bothLists.add(videosFromComedians.get(i));
    	}
    	
    	for(int i = 0; i< videosFromTags.size(); i++) {
    		bothLists.add(videosFromTags.get(i));
    	}
  
    	request.setAttribute("listVideos", bothLists);
        RequestDispatcher dispatcher = request.getRequestDispatcher("ShowSearchResults.jsp");       
        dispatcher.forward(request, response);
    
    	*/
    }
    
    
    
    // Method to insert video
    private void insertVideo(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
    	
    	boolean videoSuccessfullyInserted = false;
    	
    	// Grab user input from InsertVideoForm.jsp
    	String url = request.getParameter("url");
    	String title = request.getParameter("title");
    	String description = request.getParameter("description");
    	String tags = request.getParameter("tags");
    	String comedian = request.getParameter("comedianSelect");
    	
    	// Get comid for associated comedian
    	Integer comid = peopleDAO.getComidFromSpecificComedian(comedian);
    	
        videoSuccessfullyInserted = peopleDAO.insertVideo(url, title, description, tags, comid);
        
        if(videoSuccessfullyInserted == true) {
        	peopleDAO.insertTags(url, tags);
        }
        else {
        	System.out.print("Error: Failed to insert video into the database.");
        }
        
        response.sendRedirect("home.jsp");
        // The sendRedirect() method works at client side and sends a new request
    	}
	
    
    // Method to login
    private void login(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	
    	String email = request.getParameter("email");
        String password = request.getParameter("password");
                 
        
        try {
        	peopleDAO.people = peopleDAO.checkLogin(email, password);
            String destPage = "login.jsp";
          /*    
            if (email != null) {
                HttpSession session = request.getSession();
                session.setAttribute("user", people);
                destPage = "home.jsp";
            } else if(email.equals("root")) {
            	HttpSession session = request.getSession();
                session.setAttribute("user", people);
                destPage = "root.jsp";
            }
            else{
                String message = "Invalid email/password";
                request.setAttribute("message", message);
            }*/
            
            if(peopleDAO.people.getEmail() == null) {
            	String message = "Invalid email/password";
                request.setAttribute("message", message);
                destPage = "login.jsp";
            }
            else if (email.equals("root")) {
            		HttpSession session = request.getSession();
                    session.setAttribute("user", peopleDAO.people);
                    destPage = "root.jsp";
            	}
            else {
            		HttpSession session = request.getSession();
                    session.setAttribute("user", peopleDAO.people);
                    destPage = "home.jsp";
            	}
            
            
            RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
            dispatcher.forward(request, response);
        	
        } catch (SQLException | ClassNotFoundException | NullPointerException ex) {
        	if(ex instanceof SQLException || ex instanceof NullPointerException) {
        		String destPage = "login.jsp";
        		RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
                dispatcher.forward(request, response);
        	}else {
       
            throw new ServletException(ex);
        	}
        }
        
    }
    
    //Method to logout
    protected void logout(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.removeAttribute("user");
             
            RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
            dispatcher.forward(request, response);
        }
    }
    
    // Method to list all users in the table [Complete]
    // I am not sure that we need this function anymore
    private void listPeople(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<People> listPeople = peopleDAO.listAllPeople();
        request.setAttribute("listPeople", listPeople);       
        RequestDispatcher dispatcher = request.getRequestDispatcher("root.jsp");       
        dispatcher.forward(request, response);
    }
    
    private void listVideos(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
    	
        List<String> listVideos = peopleDAO.listAllVideos();
        request.setAttribute("listVideos", listVideos);       
        RequestDispatcher dispatcher = request.getRequestDispatcher("ShowSearchResults.jsp");       
        dispatcher.forward(request, response);
    }
 
    // Method to insert a new user into the table [Complete]
    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("InsertPeopleForm.jsp");
        dispatcher.forward(request, response);
    }
 
    // Method to display the EditPeopleForm.jsp [Complete]
    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
    	
    	String email = request.getParameter("email");
        People existingPeople = peopleDAO.getPeople(email);
        RequestDispatcher dispatcher = request.getRequestDispatcher("EditPeopleForm.jsp");
        request.setAttribute("people", existingPeople);
        dispatcher.forward(request, response); // The forward() method works at server side, and It sends the same request and response objects to another servlet.
 
    }
 
    
 // Method to insert a new user to the table [Complete]
    private void insertReview(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
    
    	
    	String remark = request.getParameter("remark");
    	String ratingString = request.getParameter("rating");
    	String url = request.getParameter("hiddenURL");
    	char rating = ratingString.charAt(0);
   
    	
    	YoutubeVideo currentVideo = peopleDAO.getVideoFromURL(url);
    	String destPage;
    	HttpSession session = request.getSession();
        destPage = "ShowVideo.jsp";
        
        // Only insert if reviewing user is not the video postuser
        String currentUser = peopleDAO.people.getEmail();
        String postuser = currentVideo.getPostuser();
        
        if(!currentUser.equals(postuser)) {
        	// Insert review
        	peopleDAO.insertReview(remark, rating, url);
        }else {
        	System.out.println("Reviews for your own videos are not allowed. Review denied.");
        }
    	
    	
    	
        
    	
    	// Must be in array to iterate over
    	YoutubeVideo[] currentVideoArray = new YoutubeVideo[1];
    	currentVideoArray[0] = currentVideo;
    	
    	request.setAttribute("currentVideo", currentVideoArray);  
        
        RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
        dispatcher.forward(request, response);
    	
    	
    	}

    // Method to insert a comedian to favorites
    private void insertFavorite(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
    
  
    	System.out.println("INSERT FAVORITE STARTED IN SERVLET");
    	String url = request.getParameter("hiddenURL");
    	//String comidString = request.getParameter("hiddenComid");
    	int comid = Integer.parseInt(request.getParameter("hiddenComid"));
    	System.out.println("COMID = " + comid);
    	
    	peopleDAO.insertFavorite(comid);
    	
    	
    	String destPage;
    	HttpSession session = request.getSession();
        destPage = "ShowVideo.jsp";
        
         
        YoutubeVideo currentVideo = peopleDAO.getVideoFromURL(url);
    	
    	// Must be in array to iterate over
    	YoutubeVideo[] currentVideoArray = new YoutubeVideo[1];
    	currentVideoArray[0] = currentVideo;
    	
    	request.setAttribute("currentVideo", currentVideoArray);  
        
        RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
        dispatcher.forward(request, response);
    	
    	
    	}
    
    // Method to insert a new user to the table [Complete]
    private void insertPeople(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
    	try {
    	String email = request.getParameter("email");
    	String password = request.getParameter("password");
    	String passwordConfirmed = request.getParameter("passwordConfirmed");
    	String firstname = request.getParameter("firstname");
    	String lastname = request.getParameter("lastname");
    	int age = Integer.parseInt(request.getParameter("age"));
    	
        People newPeople = new People(email, password, passwordConfirmed, firstname, lastname, age);
        peopleDAO.insert(newPeople);
        response.sendRedirect("list");
        // The sendRedirect() method works at client side and sends a new request
    	}catch (SQLException ex) {
        	if(ex instanceof SQLIntegrityConstraintViolationException) {
        		System.out.println("Error: Duplicate email!");	
           
        	}
    	}
    }
 
    // Method to update an individual user in the table [Complete]
    private void updatePeople(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
  
    	String email = request.getParameter("email");
    	String password = request.getParameter("password");
    	String passwordConfirmed = request.getParameter("passwordConfirmed");
    	String firstname = request.getParameter("firstname");
    	String lastname = request.getParameter("lastname");
    	int age = Integer.parseInt(request.getParameter("age"));
    	
        People people = new People(email, password, passwordConfirmed, firstname, lastname, age);
        peopleDAO.update(people);
        response.sendRedirect("list");
    }
 
    
 // Method to delete favorite
    private void deleteFavorite(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
    	
    	
        int comid = Integer.parseInt(request.getParameter("hiddenComid"));
        String email = peopleDAO.people.getEmail();
        
        peopleDAO.deleteFavorite(email, comid);

        String destPage;
        HttpSession session = request.getSession();
        destPage = "favorites.jsp";
        RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
        dispatcher.forward(request, response);
    }
    
    // Method to delete a user from the table [Complete]
    private void deletePeople(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
    	String email = request.getParameter("email");
       
        peopleDAO.delete(email);
        response.sendRedirect("list"); 
    }

}
