
public class YoutubeVideo {

	protected String url;
	protected String title;
	protected String description;
	protected String tags;
	protected int comid;
	protected String postuser;
	protected String postdate;
	
	// Default Constructor
	public YoutubeVideo() {
		this.url = "";
		this.title = "";
		this.description = "";
		this.comid = 0;
		this.postuser = "";
		this.postdate = "";
		this.tags = "";
	}
	
	// Arg Constructor
	public YoutubeVideo(String url, String title, String description, String tags, int comid, String postuser, String postdate) {
		
		this.url = url;
		this.title = title;
		this.description = description;
		this.comid = comid;
		this.postuser = postuser;
		this.postdate = postdate;
		this.tags = tags;
	}

	public String getTags() {
		return tags;
	}

	public void setTags(String tags) {
		this.tags = tags;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getComid() {
		return comid;
	}

	public void setComid(int comid) {
		this.comid = comid;
	}

	public String getPostuser() {
		return postuser;
	}

	public void setPostuser(String postuser) {
		this.postuser = postuser;
	}

	public String getPostdate() {
		return postdate;
	}

	public void setPostdate(String postdate) {
		this.postdate = postdate;
	}
	
	
	
}
