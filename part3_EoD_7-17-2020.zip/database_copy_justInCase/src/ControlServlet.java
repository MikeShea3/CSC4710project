import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
 
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
 
import java.sql.SQLIntegrityConstraintViolationException;
/**
 * ControllerServlet.java
 * This servlet acts as a page controller for the application, handling all
 * requests from the user.
 * @author www.codejava.net
 */
public class ControlServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    public PeopleDAO peopleDAO;
 
    public void init() {
        peopleDAO = new PeopleDAO(); 
    }
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();
        System.out.println(action);
        try {
            switch (action) {
            case "/new":
                showNewForm(request, response);
                break;
            case "/insert":
            	insertPeople(request, response);
                break;
            case "/delete":
            	deletePeople(request, response);
                break;
            case "/edit":
                showEditForm(request, response);
                break;
            case "/update":
            	updatePeople(request, response);
                break;
            case "/logout":
            	logout(request, response);
            	break;
            case "/login":
            	login(request, response);
            	break;
            case "/initdb":
            	initdb(request, response);
            	break;
            case "/newVideo":
            	showInsertVideoForm(request,response);
            	break;
            case "/insertVideo":
            	insertVideo(request, response);
            	break;
            case "/showSearchVideos":
            	showSearchVideos(request, response);
            	break;
            case "/searchVideos":
            	searchVideos(request, response);
            	break; 
            case "/home":
            	goHome(request, response);	// works but logs the user out - insecure
            	break;
            case "/ShowVideo":
            	goToVideo(request, response);
            	break;
            case "/insertReview":
            	insertReview(request, response);
            	break;
            case "/deleteReview":
            	//deleteReview(request, response);
            	break;
            case "/insertFavorite":
            	insertFavorite(request, response);
            	break;
            case "/deleteFavorite":
            	deleteFavorite(request, response);
            	break;
            case"/showFavorites":
            	showFavorites(request, response);
            	break;
            case"/showAllVideos":
            	showAllVideos(request, response);
            	break;
            case"/showCool":
            	showCool(request, response);
            	break;
            case"/showComedian":
            	showComedian(request, response);
            	break;
            case"/showNew":
            	showNew(request, response);
            	break;
            case"/showHot":
            	showHot(request, response);
            	break;
            case"/showTop":
            	showTop(request, response);
            	break;
            case"/showPopular":
            	showPopular(request, response);
            	break;
            case"/showCompareFavorites":
            	showCompareFavorites(request, response);
            	break;
            case"/compareFavorites":
            	compareFavorites(request, response);
            	break;
            case"/productiveUsers":
            	productiveUsers(request, response);
            	break;
            case"/showUser":
            	showUser(request, response);
            	break;
            case"/positiveUsers":
            	showPositiveUsers(request, response);
            	break;
            case"/poorVideos":
            	showPoorVideos(request, response);
            	break;
            default: 
            	listPeople(request, response);
            	break;
            	/* This line used to list people as the default. 
            	 * We want it to function as a login instead because 
            	 * we won't be listing anything in the application
            	 * because the information in sensitive. I changed the
            	 * jsp file to relfect this and now the original
            	 * list all people button says login. If we can get that to work
            	 * by using the verification in PeopleDAO, we should be good.       	
            	 */
               
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }
    
    
    
    private void showAllVideos(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
    	
    	// Get All Videos From Database
    	List<YoutubeVideo> allVideos = new ArrayList<YoutubeVideo>();
    	allVideos = peopleDAO.getAllVideos();
    	
    	
    	// Send videos to resource pool
    	request.setAttribute("listVideos", allVideos);  
    	
    	
    	// Load page with all videos
    	RequestDispatcher dispatcher = request.getRequestDispatcher("ShowAllVideos.jsp");
        dispatcher.forward(request, response);
    }
    
    
    
    
    private void showFavorites(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
    	
    	// Get Comedian Info
    	String email = peopleDAO.people.getEmail();
    	List<Integer> comidList = peopleDAO.getComidFromFavorites(email);
    	
    	// TEST
    	System.out.println("email = " + email);
    	System.out.println("COMID LIST");
    	System.out.println("============");
    	for(int i = 0; i < comidList.size(); i++) {
    		System.out.println(comidList.get(i));
    	}
    	
    	// Get Comedian objects
    	List<Comedian> comedianList;
    	comedianList = peopleDAO.getComediansFromComidList(comidList);
    	
    	// TEST
    	System.out.println("COMEDIANS");
    	System.out.println("============");
    	for(int i = 0; i< comedianList.size(); i++) {
    		System.out.println(comedianList.get(i).getFirstname());
    	}
    	

    	
    	
    	
    	// Send Comedian Objects to resource pool
    	request.setAttribute("comedianArray", comedianList);  
    	
    	// Load page with favorites
    	RequestDispatcher dispatcher = request.getRequestDispatcher("favorites.jsp");
        dispatcher.forward(request, response);
    }
    
 
    
    // Method to initialize database
    private void initdb(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
    	
    	peopleDAO.initialize();
    	String destPage;
    	HttpSession session = request.getSession();
        destPage = "root.jsp";
        RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
        dispatcher.forward(request, response);
    
    
    }
    
    
    
    private void goToVideo(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
    	
    	String url = request.getParameter("url");
    	
    	System.out.println("url = " + url);
    	
    	YoutubeVideo currentVideo = peopleDAO.getVideoFromURL(url);
    	
    	// Must be in array to iterate over
    	YoutubeVideo[] currentVideoArray = new YoutubeVideo[1];
    	currentVideoArray[0] = currentVideo;
    	
    	request.setAttribute("currentVideo", currentVideoArray);  
    	RequestDispatcher dispatcher = request.getRequestDispatcher("ShowVideo.jsp");
        dispatcher.forward(request, response);
    }
    
    // Does not work yet
    private void goHome(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	RequestDispatcher dispatcher = request.getRequestDispatcher("home.jsp");
        dispatcher.forward(request, response);
    }
        
        
    // Method to show the search videos page
    private void showSearchVideos(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	RequestDispatcher dispatcher = request.getRequestDispatcher("SearchVideoForm.jsp");
        dispatcher.forward(request, response);
    }
    
    
    // Method to insert a new user to the table [Complete]
    private void showInsertVideoForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("InsertVideoForm.jsp");
        dispatcher.forward(request, response);
    }
    
    private void searchVideos(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
    	
    
    	String input = request.getParameter("video");// Get info from search bar
    	String[] userInput = input.split(", ");	// Array of youtube videos to send to results page
    	List<Comedian> comediansFromInput = new ArrayList<Comedian>();
    	List<YoutubeTag> tagsFromInput = new ArrayList<YoutubeTag>();
    	List<YoutubeVideo> videosFromComedians = new ArrayList<YoutubeVideo>();
    	List<YoutubeVideo> videosFromTags= new ArrayList<YoutubeVideo>();
    	
    	// Get all matching comids (WORKS)
    	comediansFromInput = peopleDAO.getComedianFromInput(userInput); 	// check the user's input if they entered a comedians name and returns the comid
    	videosFromComedians = peopleDAO.relateComidToURL(comediansFromInput);
    	
    	
    	// Get all matching tags (WORKS)
    	tagsFromInput = peopleDAO.getTagsFromInput(userInput);
    	videosFromTags = peopleDAO.relateTagsToURL(tagsFromInput);
    	

    	
    	// Combine Lists
    	List<YoutubeVideo> videoList = new ArrayList<YoutubeVideo>();
    	
    	// Append videosFromComedians
    	for(int i = 0; i < videosFromComedians.size(); i++) {
    		
    		// Check that video is not already in list
    		boolean inList = false;
    		for(int j = 0; j < videoList.size(); j++) {
    			
    			if(videosFromComedians.get(i).getUrl() == videoList.get(j).getUrl()) {
    				inList = true;
    			}
    		
    		}
    		
    		if(inList == false) {
    			videoList.add(videosFromComedians.get(i));
    		}
    		
    	}
    	
    	// Append videosFromTags
    	for(int i = 0; i < videosFromTags.size(); i++) {
    		
    		// Check that video is not already in list
    		boolean inList = false;
    		for(int j = 0; j < videoList.size(); j++) {
    			
    			if(videosFromTags.get(i).getUrl() == videoList.get(j).getUrl()) {
    				inList = true;
    			}
    		
    		}
    		
    		if(inList == false) {
    			videoList.add(videosFromTags.get(i));
    		}
    		
    	}
    	
    	// Send videoList to resources and redirect page
    	request.setAttribute("listVideos", videoList);
        RequestDispatcher dispatcher = request.getRequestDispatcher("ShowSearchResults.jsp");       
        dispatcher.forward(request, response);
    	
    	/*
    	
    	// Search comedians for firstname OR lastname and get comid
    	
    	// Initialize
    	List<Integer> comid = new ArrayList<Integer>();
    	List<YoutubeVideo> videosFromComedians;
    	String input = request.getParameter("video");// Get info from search bar
    	String[] userInput = input.split(", ");	// Array of youtube videos to send to results page
    	
    	// Get all matching comids
    	comid = peopleDAO.getComidFromArray(userInput); 	// check the user's input if they entered a comedians name and returns the comid
    	
    	
    	
    	// Select URLs with matching tag
		List<YoutubeVideo> videosFromTags = peopleDAO.relateTagsToURL(userInput);// return a list of youtubevideo objects
    	
		
    	
    	// TEST
    	System.out.println("input = " +input);
    	for(int i = 0; i <userInput.length; i++) {
    		System.out.println("index " + i + " = " + userInput[i]);
    	}
    	System.out.println("SPLIT STRING:");
    	System.out.println("============");
    	for(int i = 0; i < userInput.length; i++) {
    		System.out.println(i + " " + userInput[i]);
    	}
    	
    		
		// Get Comedian objects
		List<Comedian> comedianList = new ArrayList<Comedian>();
		comedianList = peopleDAO.getComedianFromComid(comid);
    	
		for(int i = 0; i < comedianList.size(); i++) {
			System.out.println("comedian identified: " + comedianList.get(i).getFirstname());
			System.out.println("comid = " + comedianList.get(i).getComid());
		}
		
		// Get videos where comedian exists
		videosFromComedians = peopleDAO.relateComidToURL(comedianList);

	
    	// Concat both lists together
    	List<YoutubeVideo> bothLists = new ArrayList<YoutubeVideo>();
    	for(int i = 0; i < videosFromComedians.size(); i++) {
    		bothLists.add(videosFromComedians.get(i));
    	}
    	
    	for(int i = 0; i< videosFromTags.size(); i++) {
    		bothLists.add(videosFromTags.get(i));
    	}
  
    	request.setAttribute("listVideos", bothLists);
        RequestDispatcher dispatcher = request.getRequestDispatcher("ShowSearchResults.jsp");       
        dispatcher.forward(request, response);
    
    	*/
    }
    
    
    
    // Method to insert video
    private void insertVideo(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
    	
    	boolean tagsSuccessfullyInserted = false;
    	boolean videoSuccessfullyInserted = false;
    	
    	// Grab user input from InsertVideoForm.jsp
    	String url = request.getParameter("url");
    	String title = request.getParameter("title");
    	String description = request.getParameter("description");
    	String tags = request.getParameter("tags");
    	String comedian = request.getParameter("comedianSelect");
    	
    	// Get comid for associated comedian
    	Integer comid = peopleDAO.getComidFromSpecificComedian(comedian);
    	
        videoSuccessfullyInserted = peopleDAO.insertVideo(url, title, description, tags, comid);
        
        // TEST
        //System.out.println("Video successfully inserted = " + videoSuccessfullyInserted);
        
        if(videoSuccessfullyInserted == true) {
        	tagsSuccessfullyInserted = peopleDAO.insertTags(url, tags);
        	
        	// TEST
            System.out.println("Tags successfully inserted = " + tagsSuccessfullyInserted);
        }
        else {
        	System.out.print("Error: Failed to insert video into the database.");
        }
        
        response.sendRedirect("home.jsp");
        // The sendRedirect() method works at client side and sends a new request
    	}
	
    
    // Method to login
    private void login(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	
    	String email = request.getParameter("email");
        String password = request.getParameter("password");
                 
        
        try {
        	peopleDAO.people = peopleDAO.checkLogin(email, password);
            String destPage = "login.jsp";
          /*    
            if (email != null) {
                HttpSession session = request.getSession();
                session.setAttribute("user", people);
                destPage = "home.jsp";
            } else if(email.equals("root")) {
            	HttpSession session = request.getSession();
                session.setAttribute("user", people);
                destPage = "root.jsp";
            }
            else{
                String message = "Invalid email/password";
                request.setAttribute("message", message);
            }*/
            
            if(peopleDAO.people.getEmail() == null) {
            	String message = "Invalid email/password";
                request.setAttribute("message", message);
                destPage = "login.jsp";
            }
            else if (email.equals("root")) {
            		HttpSession session = request.getSession();
                    session.setAttribute("user", peopleDAO.people);
                    destPage = "root.jsp";
            	}
            else {
            		HttpSession session = request.getSession();
                    session.setAttribute("user", peopleDAO.people);
                    destPage = "home.jsp";
            	}
            
            
            RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
            dispatcher.forward(request, response);
        	
        } catch (SQLException | ClassNotFoundException | NullPointerException ex) {
        	if(ex instanceof SQLException || ex instanceof NullPointerException) {
        		String destPage = "login.jsp";
        		RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
                dispatcher.forward(request, response);
        	}else {
       
            throw new ServletException(ex);
        	}
        }
        
    }
    
    //Method to logout
    protected void logout(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.removeAttribute("user");
             
            RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
            dispatcher.forward(request, response);
        }
    }
    
    // Method to list all users in the table [Complete]
    // I am not sure that we need this function anymore
    private void listPeople(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<People> listPeople = peopleDAO.listAllPeople();
        request.setAttribute("listPeople", listPeople);       
        RequestDispatcher dispatcher = request.getRequestDispatcher("root.jsp");       
        dispatcher.forward(request, response);
    }
    
    private void listVideos(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
    	
        List<String> listVideos = peopleDAO.listAllVideos();
        request.setAttribute("listVideos", listVideos);       
        RequestDispatcher dispatcher = request.getRequestDispatcher("ShowSearchResults.jsp");       
        dispatcher.forward(request, response);
    }
 
    // Method to insert a new user into the table [Complete]
    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("InsertPeopleForm.jsp");
        dispatcher.forward(request, response);
    }
 
    // Method to display the EditPeopleForm.jsp [Complete]
    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
    	
    	String email = request.getParameter("email");
        People existingPeople = peopleDAO.getPeople(email);
        RequestDispatcher dispatcher = request.getRequestDispatcher("EditPeopleForm.jsp");
        request.setAttribute("people", existingPeople);
        dispatcher.forward(request, response); // The forward() method works at server side, and It sends the same request and response objects to another servlet.
 
    }
 
    
 // Method to insert a new user to the table [Complete]
    private void insertReview(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
    
    	
    	// Grab data from input fields
    	String remark = request.getParameter("remark");
    	String ratingString = request.getParameter("rating");
    	String url = request.getParameter("hiddenURL");
    	char rating = ratingString.charAt(0);
   
    	// Destination pages and outgoing resources
    	YoutubeVideo currentVideo = peopleDAO.getVideoFromURL(url);
    	String destPage;
    	HttpSession session = request.getSession();
        destPage = "ShowVideo.jsp";
        
        // Only insert if reviewing user is not the video postuser
        String currentUser = peopleDAO.people.getEmail();
        
        //System.out.println("Current user = " + currentUser);
        
        String postuser = currentVideo.getPostuser();
        
        if(!currentUser.equals(postuser)) {
        	// Insert review
        	peopleDAO.insertReview(remark, rating, url, currentUser);
        }else {
        	System.out.println("Reviews for your own videos are not allowed. Review denied.");
        }
    	
    	
    	
        
    	
    	// Must be in array to iterate over
    	YoutubeVideo[] currentVideoArray = new YoutubeVideo[1];
    	currentVideoArray[0] = currentVideo;
    	
    	request.setAttribute("currentVideo", currentVideoArray);  
        
        RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
        dispatcher.forward(request, response);
    	
    	
    	}

    // Method to insert a comedian to favorites
    private void insertFavorite(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
    
  
    	System.out.println("INSERT FAVORITE STARTED IN SERVLET");
    	String url = request.getParameter("hiddenURL");
    	//String comidString = request.getParameter("hiddenComid");
    	int comid = Integer.parseInt(request.getParameter("hiddenComid"));
    	System.out.println("COMID = " + comid);
    	
    	peopleDAO.insertFavorite(comid);
    	
    	
    	String destPage;
    	HttpSession session = request.getSession();
        destPage = "ShowVideo.jsp";
        
         
        YoutubeVideo currentVideo = peopleDAO.getVideoFromURL(url);
    	
    	// Must be in array to iterate over
    	YoutubeVideo[] currentVideoArray = new YoutubeVideo[1];
    	currentVideoArray[0] = currentVideo;
    	
    	request.setAttribute("currentVideo", currentVideoArray);  
        
        RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
        dispatcher.forward(request, response);
    	
    	
    	}
    
    // Method to insert a new user to the table [Complete]
    private void insertPeople(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
    	try {
    	String email = request.getParameter("email");
    	String password = request.getParameter("password");
    	String passwordConfirmed = request.getParameter("passwordConfirmed");
    	String firstname = request.getParameter("firstname");
    	String lastname = request.getParameter("lastname");
    	int age = Integer.parseInt(request.getParameter("age"));
    	
        People newPeople = new People(email, password, passwordConfirmed, firstname, lastname, age);
        peopleDAO.insert(newPeople);
        response.sendRedirect("list");
        // The sendRedirect() method works at client side and sends a new request
    	}catch (SQLException ex) {
        	if(ex instanceof SQLIntegrityConstraintViolationException) {
        		System.out.println("Error: Duplicate email!");	
           
        	}
    	}
    }
 
    // Method to update an individual user in the table [Complete]
    private void updatePeople(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
  
    	String email = request.getParameter("email");
    	String password = request.getParameter("password");
    	String passwordConfirmed = request.getParameter("passwordConfirmed");
    	String firstname = request.getParameter("firstname");
    	String lastname = request.getParameter("lastname");
    	int age = Integer.parseInt(request.getParameter("age"));
    	
        People people = new People(email, password, passwordConfirmed, firstname, lastname, age);
        peopleDAO.update(people);
        response.sendRedirect("list");
    }
 
    
 // Method to delete favorite
    private void deleteFavorite(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
    	
    	
        int comid = Integer.parseInt(request.getParameter("hiddenComid"));
        String email = peopleDAO.people.getEmail();
        
        peopleDAO.deleteFavorite(email, comid);

        String destPage;
        HttpSession session = request.getSession();
        destPage = "favorites.jsp";
        RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
        dispatcher.forward(request, response);
    }
    
    // Method to delete a user from the table [Complete]
    private void deletePeople(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
    	String email = request.getParameter("email");
       
        peopleDAO.delete(email);
        response.sendRedirect("list"); 
    }

    
    
    private void showCool(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
    	
    	// Get Cool Comedians (have reviews, all excellent)
    	List<Comedian> coolComedians = new ArrayList<Comedian>();
    	coolComedians = peopleDAO.getCoolComedians();
    	
    	
    	// Send videos to resource pool
    	request.setAttribute("listComedians", coolComedians);  
    	
    	
    	// Load page with all videos
    	RequestDispatcher dispatcher = request.getRequestDispatcher("ShowCoolComedians.jsp");
        dispatcher.forward(request, response);
    }
    
    private void showComedian(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, NumberFormatException {
    	
    	// Grab comid from previous page
    	String comidString = request.getParameter("comid");
    	
   
    	int comid = Integer.parseInt(comidString);
    	Comedian chosenComedian = peopleDAO.getComedianFromComid(comid);
    	
    	// Get list of videos for corresponding comid
    	List<Comedian> comedianList = new ArrayList<Comedian>();
    	comedianList.add(chosenComedian);
    	List<YoutubeVideo> comedianVideos = new ArrayList<YoutubeVideo>();
    	//comedianList = peopleDAO.getComediansFromComidList(comidList);
    	comedianVideos = peopleDAO.relateComidToURL(comedianList);
    
    	
    	
    	
    	request.setAttribute("listVideos", comedianVideos);  
    	request.setAttribute("comedianList", comedianList);  
    	RequestDispatcher dispatcher = request.getRequestDispatcher("ShowComedian.jsp");
        dispatcher.forward(request, response);
    
    }
    
    private void showNew (HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, NumberFormatException {
    	
    	List<Integer> comidList = new ArrayList<Integer>();
    	comidList = peopleDAO.getNewComedians();
    	
    	List<Comedian> comedianList = new ArrayList<Comedian>();
    	comedianList = peopleDAO.getComediansFromComidList(comidList);
    	
    	request.setAttribute("comedianList", comedianList);  
    	RequestDispatcher dispatcher = request.getRequestDispatcher("ShowNew.jsp");
        dispatcher.forward(request, response);
    	
    }
    
    private void showHot(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, NumberFormatException {
    	
    	List<Comedian> comedianList = new ArrayList<Comedian>();
    	
    	comedianList = peopleDAO.getHotComedians();
    	
    	request.setAttribute("comedianList", comedianList);  
    	RequestDispatcher dispatcher = request.getRequestDispatcher("ShowHot.jsp");
        dispatcher.forward(request, response);
    	
    }
    
    private void showTop(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, NumberFormatException {
    	
    	List<Comedian> comedianList = new ArrayList<Comedian>();
    	
    	comedianList = peopleDAO.getTopComedians();
    	
    	request.setAttribute("comedianList", comedianList);  
    	RequestDispatcher dispatcher = request.getRequestDispatcher("ShowTop.jsp");
        dispatcher.forward(request, response);
    
    }
    
    private void showPopular(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, NumberFormatException {
    	
    	List<YoutubeTag> listForDisplay = new ArrayList<YoutubeTag>();
    	
    	List<String> allTags = new ArrayList<String>();
    	allTags = peopleDAO.getAllTags();
    	
    	
    	// TEST
    	for(int i = 0; i < allTags.size(); i++) {
    		System.out.println("TEST tag = " + allTags.get(i));
    	}
    	
    	
    	List<People> allUsers = new ArrayList<People>();
    	allUsers = peopleDAO.getAllUsers();
    	
    	/*
    	// TEST
    	for(int i = 0; i < allUsers.size(); i++) {
    		System.out.println("User = " + allUsers.get(i).getEmail());
    	}
    	*/
    	
    	List<YoutubeVideo> allVideos = new ArrayList<YoutubeVideo>();
    	allVideos = peopleDAO.getAllVideos();
    	
    	// Final List
    	List<String> tagsFromAllUsers = new ArrayList<String>();
    	
    	// Temp List
    	List<String> tempTags = new ArrayList<String>();
    	
    	// TEST
    	for(int i = 0; i < tempTags.size(); i++) {
    		System.out.println("Tag = " + tempTags.get(i));
    	}
    	
    	// Iterate over all users
    	for(int i = 0; i < allUsers.size(); i++) {
    		
    		System.out.println("Starting " + i + " user");
    		
    		List<String> currentUserTags = new ArrayList<String>();
    		
    		// Iterate over all videos
    		for(int j = 0; j < allVideos.size(); j++) {
    			
    			System.out.println("Starting " + j + " video");
    			
    			// TEST
    			System.out.println("Checking video = " + allVideos.get(j).getUrl());
    			
    			// Determine if user posted video
    			if(allUsers.get(i).getEmail().equals(allVideos.get(j).getPostuser())) {
    				System.out.println("Found user who posted video");
    				currentUserTags.add(allVideos.get(j).getTags());
    			}
    			
    			
    			System.out.println("Ending " + j + " video");
    		}
    		
    		
    		// currentUserTags now contains all tags posted by this user
    		// First user
    		if(tagsFromAllUsers.size() == 0) {
    			System.out.println("Size of currentUserTags = " + currentUserTags.size());
    			for(int k = 0; k < currentUserTags.size(); k++) {
    				System.out.println("Added tags from initial user");
    				tagsFromAllUsers.add(currentUserTags.get(k));
    			}
    		}
    		// All other users (loop over current tags, remove from final if not matching)
    		else {
    			
    			System.out.println("Adding tags from consecutive user");
    			for(int l = 0; l < currentUserTags.size(); l++) {
    				
    				boolean matchFound = false;
    				
    				// Iterate over all tempTags
    				for(int m = 0; m < tempTags.size(); m++) {
    					
    					// Match Found
    					if(currentUserTags.get(l).equals(tempTags.get(m))) {
    						matchFound = true;
    						System.out.println("Matching tag found = " + currentUserTags.get(l));
    					}
    					
    				}
    				
    				if(matchFound) {
    					
    					// Check if already on the list
    					boolean alreadyOnList = false;
    					for(int x = 0; x < tagsFromAllUsers.size(); x++) {
    						for(int y = 0; y < currentUserTags.size(); y++) {
    							
    							
    							
    						
    						
    						// Match found
    						if(tagsFromAllUsers.get(x).equals(currentUserTags.get(y))) {
    							alreadyOnList = true;
    						}
    				
    					
	    					// Add to final list
	    					if(!alreadyOnList) {
	    						tagsFromAllUsers.add(currentUserTags.get(y));
	    					}
    					
    					}
    					
    				}
    			}

    				
    		}
    	}
    		
    	System.out.println("Ending " + i + " user");
    }
    	
    	
    	// TEST
    	System.out.println("Size of tagsFromAllUsers = " + tagsFromAllUsers.size());
    	for(int i = 0; i < tagsFromAllUsers.size(); i++) {
    		System.out.println("Tag = " + tagsFromAllUsers.get(i));
    	}
    	
    	
    	
    	List<String> finalList = new ArrayList<String>();
    	
    	for(int i = 0; i < tagsFromAllUsers.size(); i++) {
    		
    		if(finalList.contains(tagsFromAllUsers.get(i))) {
    			
    		}
    		else {
    			finalList.add(tagsFromAllUsers.get(i));
    			
    		}
    	}
    	
    	for(int i = 0; i < finalList.size(); i++) {
    		YoutubeTag tempTag = new YoutubeTag();
    		tempTag.setTag(finalList.get(i));
    		listForDisplay.add(tempTag);
    	}
    	
    	
    	for(int i = 0; i < finalList.size(); i++) {
    		System.out.println("final list = " + finalList.get(i));
    	}
    	
    	
    	// Send tags to ShowTags.jsp
    	request.setAttribute("finalList", listForDisplay);  
    	RequestDispatcher dispatcher = request.getRequestDispatcher("ShowPopular.jsp");
        dispatcher.forward(request, response);
    }
    
    private void showCompareFavorites(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, NumberFormatException {
    
    	
    	 RequestDispatcher dispatcher = request.getRequestDispatcher("ShowCompareFavorites.jsp");
         dispatcher.forward(request, response);
    	
    }
    
    
    private void compareFavorites(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, NumberFormatException {
    
    	// Get user email from webpage
    	String user1 = request.getParameter("firstUser");
    	String user2 = request.getParameter("secondUser");
    	
    	// TEST
    	System.out.println("First user email = " + user1);
    	
    	// Get User Objects
    	People firstUser = peopleDAO.getPeople(user1);
    	People secondUser = peopleDAO.getPeople(user2);
    	
    	System.out.println("First user name = " + firstUser.getFirstname());
    	
    	// Get Favorite Comedians For Each User
    	List<IsFavorite> firstUserFavorites = new ArrayList<IsFavorite>();
    	List<IsFavorite> secondUserFavorites = new ArrayList<IsFavorite>();
    	
    	firstUserFavorites = peopleDAO.getFavoriteComedians(firstUser);
    	secondUserFavorites = peopleDAO.getFavoriteComedians(secondUser);
    	
    	// Find Common Comedians
    	List<Integer> comidList1 = new ArrayList<Integer>();    	
    	for(int i = 0; i < firstUserFavorites.size(); i++) {
    		comidList1.add(firstUserFavorites.get(i).getComid());
    	}
    	
    	List<Integer> comidList2 = new ArrayList<Integer>();
    	for(int i = 0; i < secondUserFavorites.size(); i++) {
    		comidList2.add(secondUserFavorites.get(i).getComid());
    	}
    	
    	List<Integer> commonComedians = new ArrayList<Integer>();
    	List<Integer> temp = new ArrayList<Integer>();
    	
    	temp = comidList1;
    	temp.retainAll(comidList2);
    	
    	commonComedians = temp;
    	
    	// TEST
    	/*
    	System.out.println("Common comedian size = " + commonComedians.size());
    	for(int i = 0; i < commonComedians.size(); i++) {
    		System.out.println("Common comid = " + commonComedians.get(i));
    	}
    	*/
    	
    	// Get Comedian objects from comid list
    	List<Comedian> listComedians = new ArrayList<Comedian>();
    	
    	for(int i = 0; i < commonComedians.size(); i++) {
    		Comedian tempComedian = new Comedian();
    		tempComedian = peopleDAO.getComedianFromComid(commonComedians.get(i));
    		listComedians.add(tempComedian);
    	}
    	
    	// Send common comedians to ShowCommonComedians.jsp
    	request.setAttribute("listComedians", listComedians);  
    	RequestDispatcher dispatcher = request.getRequestDispatcher("ShowCommonComedians.jsp");
        dispatcher.forward(request, response);
    }
    
    
    private void productiveUsers(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, NumberFormatException {
    
    	// Get productive users
    	List<People> productiveUsers = new ArrayList<People>();
    	
    	productiveUsers = peopleDAO.getProductiveUsers();
    	
    	// Send productive user to webpage
    	request.setAttribute("productiveUsers", productiveUsers);  
    	RequestDispatcher dispatcher = request.getRequestDispatcher("ShowProductiveUsers.jsp");
        dispatcher.forward(request, response);
    }
    	
    private void showUser(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, NumberFormatException {
    	
    	String email = request.getParameter("email");
   
    	List<YoutubeVideo> videosFromUser = new ArrayList<YoutubeVideo>();
    	videosFromUser = peopleDAO.getVideosFromEmail(email);
    	
    	
    	// TEST
    	System.out.println("VideosFromUser size = " + videosFromUser.size());
    	for(int i = 0; i < videosFromUser.size(); i++) {
    		System.out.println("Video url = " + videosFromUser.get(i).getUrl());
    	}
    	
    	// Send videos to page
    	request.setAttribute("videosFromUser", videosFromUser); 
    	request.setAttribute("email", email);
    	RequestDispatcher dispatcher = request.getRequestDispatcher("ShowVideosFromUser.jsp");
        dispatcher.forward(request, response);
    }
    
    private void showPositiveUsers(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, NumberFormatException {
    	
    		List<People> positiveUsers = new ArrayList<People>();
    		List<String> authors = new ArrayList<String>();
    		
    		authors = peopleDAO.getPositiveAuthors();
    		positiveUsers = peopleDAO.getPositiveUsers(authors);
    		
    		request.setAttribute("positiveUsers", positiveUsers); 
        	RequestDispatcher dispatcher = request.getRequestDispatcher("ShowPositiveUsers.jsp");
            dispatcher.forward(request, response);
    		
      }
    
    private void showPoorVideos(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, NumberFormatException {
    	
    	
    		List<YoutubeVideo> poorVideos = new ArrayList<YoutubeVideo>();
    		poorVideos = peopleDAO.getPoorVideos();
    		
    		request.setAttribute("poorVideos", poorVideos); 
        	RequestDispatcher dispatcher = request.getRequestDispatcher("ShowPoorVideos.jsp");
            dispatcher.forward(request, response);
    }
}