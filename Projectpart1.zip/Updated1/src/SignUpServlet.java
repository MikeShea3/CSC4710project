import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 
public class SignUpServlet extends HttpServlet {
 
     public SignUpServlet() {
     }
 
     protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Copying all the input parameters in to local variables
         String firstName = request.getParameter("firstname");
         String lastName = request.getParameter("lastname");
         String age = request.getParameter("age");
         String email = request.getParameter("email");
         String password = request.getParameter("password");
         String passwordConfirmed = request.getParameter("passwordConfirmed");
         
         SignUp signup = new SignUp();

         signup.setFirstName(firstName);
         signup.setLastName(lastName);
         signup.setAge(age);
         signup.setEmail(email);
         signup.setPassword(password);
         signup.setPasswordConfirmed(passwordConfirmed);
         
         UserDAO userDao = new UserDAO();
         
        //The core Logic of the Registration application is present here. We are going to insert user data in to the database.
         String userRegistered = userDao.registerUser(signup);
         
         if(userRegistered.equals("SUCCESS"))   //On success, you can display a message to user on Home page
         {
            request.getRequestDispatcher("/Home.jsp").forward(request, response);
         }
         else   //On Failure, display a meaningful message to the User.
         {
            request.setAttribute("errMessage", userRegistered);
            request.getRequestDispatcher("/SignUp.jsp").forward(request, response);
         }
     }
}