import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

 
public class UserDAO { 
     public String registerUser(SignUp signup)
     {
         String firstName = signup.getFirstName();
         String lastName = signup.getLastName();
         String age = signup.getAge();
         String email = signup.getEmail();
         String password = signup.getPassword();
         String passwordConfirmed = signup.getPasswordConfirmed();
         
         Connection con = null;
         PreparedStatement preparedStatement = null;         
         try
         {
             con = DBconnection.createConnection();
             String query = "insert into users(firstName,lastName,age,email,password,passwordConfirmed) values (?,?,?,?,?,?)"; //Insert user details into the table 'USERS'
             preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
             preparedStatement.setString(1, firstName);
             preparedStatement.setString(2, lastName);
             preparedStatement.setString(3, age);
             preparedStatement.setString(4, email);
             preparedStatement.setString(5, password);
             preparedStatement.setString(6, passwordConfirmed);
             
             int i= preparedStatement.executeUpdate();
             
             if (i!=0)  //Just to ensure data has been inserted into the database
             return "SUCCESS"; 
         }
         catch(SQLException e)
         {
            e.printStackTrace();
         }       
         return "Error when connecting to the database.";  // On failure, send a message from here.
     }
}