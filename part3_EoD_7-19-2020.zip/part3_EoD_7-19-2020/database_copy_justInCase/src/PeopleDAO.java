import java.io.IOException;

import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Servlet implementation class Connect
 */
@WebServlet("/PeopleDAO")
public class PeopleDAO {

	// Private PeopleDAO Globals
	private static final long serialVersionUID = 1L;
	private Connection connect = null;
	private Statement statement = null;
	private PreparedStatement preparedStatement = null;
	private ResultSet resultSet = null;

	// Public PeopleDAO Globals (to allow storage of certain database elements)
	public People people = new People();

	// Method to initialize a PeopleDAO object [Complete]
	public PeopleDAO() {
		People people = new People();
	}

	// Method to connect to the database [Complete]
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	protected void connect_func() throws SQLException {
		if (connect == null || connect.isClosed()) {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				throw new SQLException(e);
			}
			connect = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/testdb?"
					+ "allowPublicKeyRetrieval=true&useSSL=false&user=john&password=pass1234");
			System.out.println(connect);
		}
	}

	/*
	 * Method to check login information against the database I know that the idea
	 * here is right but I think there is something wrong with the connection
	 * statement
	 */
	
	
	public People checkLogin(String email, String password) throws SQLException, ClassNotFoundException {
		connect_func();
		Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/testdb?useSSL=false&characterEncoding=UTF-8", "john",
				"pass1234");
		String sql = "SELECT * FROM user WHERE email =? and password =?";
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, email);
		statement.setString(2, password);

		ResultSet result = statement.executeQuery();

		People people = null;

		if (result.next()) {
			people = new People();
			people.setEmail(result.getString("email"));
			people.setAge(result.getInt("age"));
			people.setFirstname(result.getString("firstname"));
			people.setLastname(result.getString("lastname"));
		}

		else {
			System.out.println("Invalid email or password. Please try again or create an account first.");
		}

		connection.close();

		return people;
	}

	// Method to list all members of the User database [Complete]
	public List<People> listAllPeople() throws SQLException {
		List<People> listPeople = new ArrayList<People>();
		String sql = "SELECT * FROM user";
		connect_func();
		statement = (Statement) connect.createStatement();
		ResultSet resultSet = statement.executeQuery(sql);

		while (resultSet.next()) {
			// Query every entity for data
			String email = resultSet.getString("email");
			String password = resultSet.getString("password");
			String passwordConfirmed = resultSet.getString("passwordConfirmed");
			String firstname = resultSet.getString("firstname");
			String lastname = resultSet.getString("lastname");
			int age = resultSet.getInt("age");

			// Create object from queried data
			People people = new People(email, password, passwordConfirmed, firstname, lastname, age);
			listPeople.add(people);
		}
		resultSet.close();
		statement.close();
		disconnect();
		return listPeople;
	}
	
	// Method to select all videos from youtubevideos
	public List<String> listAllVideos() throws SQLException {
		
		
		List<String> listVideos = new ArrayList<String>();
		String sql = "SELECT Distinct url FROM youtubevideos";
		connect_func();
		statement = (Statement) connect.createStatement();
		ResultSet resultSet = statement.executeQuery(sql);

		while (resultSet.next()) {
			// Query every entity for data
			String url = resultSet.getString("url");

			// Create object from queried data
			
			listVideos.add(url);
		}
		resultSet.close();
		statement.close();
		disconnect();
		return listVideos;
	}
	


	// Method to disconnect from the MySQL server [Complete]
	protected void disconnect() throws SQLException {
		if (connect != null && !connect.isClosed()) {
			connect.close();
		}
	}

	public void initialize() throws SQLException {
		connect_func();

		System.out.println("Initializing Database, please wait...");
		// Drop tables
		String sql1 = "DROP TABLE IF EXISTS reviews;";
		String sql2 = "DROP TABLE IF EXISTS youtubeTags;";
		String sql3 = "DROP TABLE IF EXISTS isFavorite;";
		String sql4 = "DROP TABLE IF EXISTS youtubevideos;";
		String sql5 = "DROP TABLE IF EXISTS comedians;";
		String sql6 = "DROP TABLE IF EXISTS user;";

		// Create tables
		String sql7 = "CREATE TABLE user " + "(email varchar (50), " + " firstname varchar(50), "
				+ " lastname varchar(50), " + " password varchar(50), " + " passwordConfirmed varchar(50), "
				+ "age integer, " + "primary key (email), " + "UNIQUE(email), " + "CHECK(password=passwordConfirmed)"
				+ ");";

		String sql8 = "CREATE TABLE comedians" + "(comid integer, " + " firstname varchar(50), "
				+ " lastname varchar(50), " + " birthday date, " + " birthplace varchar(50), "
				+ " primary key(comid));";
		String sql9 = "CREATE TABLE youtubevideos" + "(url varchar(150) NOT NULL, " + "title varchar(50),"
				+ "description varchar(200)," + "tags varchar(150)," + "comid integer not null," + "postuser varchar(50) " + "not null,"
				+ "postdate date," + "primary key (url)," + "foreign key (comid) " + "references comedians(comid),"
				+ "foreign key(postuser) references user(email));";
		String sql10 = "CREATE TABLE reviews" + "(reviewid INTEGER NOT NULL AUTO_INCREMENT," + "remark VARCHAR(100),"
				+ "rating CHAR(1)," + "author VARCHAR(50) NOT NULL," + "youtubeid varchar(150) NOT NULL,"
				+ "primary key(reviewid)," + "FOREIGN KEY(author) REFERENCES user(email),"
				+ "FOREIGN KEY(youtubeid) REFERENCES youtubevideos(url),"
				+ "CONSTRAINT ratingck CHECK (rating IN ('P', 'F', 'G', 'E')));";
		String sql11 = "CREATE TABLE youtubetags(" + "url VARCHAR(150)," + "tag VARCHAR(50),"
				+ "primary key(url, tag));";
		String sql12 = "CREATE TABLE isFavorite(" + "email VARCHAR(50)," + "comid INTEGER,"
				+ "primary key(email, comid)," + "FOREIGN KEY(email) REFERENCES user(email),"
				+ "FOREIGN KEY(comid) REFERENCES comedians(comid));";

		// Create Triggers
		String noMoreThanFive =
				"CREATE TRIGGER NoMoreThanFive \r\n" + 
				"BEFORE INSERT \r\n" + 
				"ON youtubevideos\r\n" + 
				"FOR EACH ROW \r\n" + 
				"BEGIN \r\n" + 
				"     IF ( 5 =  (SELECT count(*) from youtubevideos Y \r\n" + 
				"	         where Y.postuser = NEW.postuser AND 	DATE(postdate) = NEW.postdate)) THEN SIGNAL SQLSTATE '45000'; \r\n" + 
				"     END IF;        \r\n" + 
				"END\r\n;";
		
		String embedVideo = "create trigger embedthevideo before insert on youtubevideos for each row SET NEW.url = REPLACE(NEW.url, \"https://www.youtube.com/watch?v=\", \"https://www.youtube.com/embed/\")";
		
			
		
		// Populate user table
		String sql13 = "INSERT INTO user values('root', 'System', 'Administrator', 'pass1234', 'pass1234', 99);";
		String sql14 = "INSERT INTO user values('mike@gmail.com', 'Mike', 'Shea', 'pass1234', 'pass1234', 28);";
		String sql15 = "INSERT INTO user values('frino@gmail.com', 'Frino', 'Jais', 'pass1234', 'pass1234', 28);";
		String sql16 = "INSERT INTO user values('jim@gmail.com', 'Jim', 'Thomas', 'berry', 'berry', 29);";
		String sql17 = "INSERT INTO user values('frankie@gmail.com', 'Frankie', 'Jackson', 'apple', 'apple', 21);";
		String sql18 = "INSERT INTO user values('dwight@gmail.com', 'Dwight', 'Frank', 'banana', 'banana', 35);";
		String sql19 = "INSERT INTO user values('phyllis@gmail.com', 'Phyllis', 'Valentine', 'orange', 'orange', 65);";
		String sql20 = "INSERT INTO user values('erin@gmail.com', 'Erin', 'Diesel', 'grapes', 'grapes', 13);";
		String sql21 = "INSERT INTO user values('todd@gmail.com', 'Todd', 'Smith', 'cherries', 'cherries', 46);";
		String sql22 = "INSERT INTO user values('stanley@gmail.com', 'Stanley', 'Snow', 'hotdogs', 'hotdogs', 53);";

		// Populate comedians table
		String sql23 = "INSERT INTO comedians values(1, 'Funny', 'Guy', '1980-01-01', 'Detroit')";
		String sql24 = "INSERT INTO comedians values(2, 'Dudes', 'Hilarious', '1970-05-10', 'Chicago')";
		String sql25 = "INSERT INTO comedians values(3, 'Silly', 'Boi', '1990-02-02', 'New York')";
		String sql26 = "INSERT INTO comedians values(4, 'Whatta', 'Jokester', '1975-10-10', 'San Diego');";
		String sql27 = "INSERT INTO comedians values(5, 'Hysterical', 'Anecdote', '1970-09-09', 'Springfield');";
		String sql28 = "INSERT INTO comedians values(6, 'Comical', 'Comic', '1965-08-08', 'Des Moines');";
		String sql29 = "INSERT INTO comedians values(7, 'Absurd', 'Storyteller', '1960-07-07', 'Richmond');";
		String sql30 = "INSERT INTO comedians values(8, 'Slapstick', 'Steve', '1955-06-06', 'Flint');";
		String sql31 = "INSERT INTO comedians values(9, 'Entertaining', 'Night-out', '1950-05-05', 'Seattle');";
		String sql32 = "INSERT INTO comedians values(10, 'Preposterous', 'Baffoon', '1976-06-05', 'Houston');";

		statement = connect.createStatement();
		
		// Drop tables
		System.out.println("Dropping tables...");
		statement.executeUpdate(sql1);
		statement.executeUpdate(sql2);
		statement.executeUpdate(sql3);
		statement.executeUpdate(sql4);
		statement.executeUpdate(sql5);
		statement.executeUpdate(sql6);
		
		// Create Tables
		System.out.println("Creating tables...");
		statement.executeUpdate(sql7);
		statement.executeUpdate(sql8);
		statement.executeUpdate(sql9);
		statement.executeUpdate(sql10);
		statement.executeUpdate(sql11);
		statement.executeUpdate(sql12);
		
		// Populate Tables
		System.out.println("Populating tables...");
		statement.executeUpdate(sql13);
		statement.executeUpdate(sql14);
		statement.executeUpdate(sql15);
		statement.executeUpdate(sql16);
		statement.executeUpdate(sql17);
		statement.executeUpdate(sql18);
		statement.executeUpdate(sql19);
		statement.executeUpdate(sql20);
		statement.executeUpdate(sql21);
		statement.executeUpdate(sql22);
		statement.executeUpdate(sql23);
		statement.executeUpdate(sql24);
		statement.executeUpdate(sql25);
		statement.executeUpdate(sql26);
		statement.executeUpdate(sql27);
		statement.executeUpdate(sql28);
		statement.executeUpdate(sql29);
		statement.executeUpdate(sql30);
		statement.executeUpdate(sql31);
		statement.executeUpdate(sql32);
		
		// Create Triggers
		System.out.println("Creating triggers...");
		statement.executeUpdate(noMoreThanFive);
		statement.executeUpdate(embedVideo);

		
		System.out.println("Database initialized!");
	}

	// Method to insert a user into the table [Complete]
	public boolean insertVideo(String url, String title, String description, String tags, Integer comid) throws SQLException {
		
		try {
		connect_func();
		String sql = "insert into youtubevideos(url, title, description, tags, comid, postuser, postdate) values (?,?,?,?,?,?,?)";

		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
		preparedStatement.setString(1, url);
		preparedStatement.setString(2, title);
		preparedStatement.setString(3, description);
		preparedStatement.setString(4, tags);
		preparedStatement.setInt(5, comid);
		preparedStatement.setString(6, people.getEmail());
		preparedStatement.setDate(7, new java.sql.Date(System.currentTimeMillis()));
//		preparedStatement.executeUpdate();

		boolean rowInserted = preparedStatement.executeUpdate() > 0;

		System.out.println(rowInserted);
		preparedStatement.close();
//        disconnect();
		return rowInserted;
		}
		catch(SQLException e) {
			System.out.println("You have already entered five videos today. Failed to create video.");
			return false;
		}
	}
	
	
	
	
	
	public boolean insertTags(String url, String tags) throws SQLException {
		
		connect_func();
		boolean rowInserted = false;
		
		// Split tags by comma
		String[] tag = tags.split(",");
		
		for(int i = 0; i < tag.length; i++) {
			String sql = "insert into youtubetags(url, tag) values (?,?)";

			preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
			preparedStatement.setString(1, url);
			preparedStatement.setString(2, tag[i]);
//			preparedStatement.executeUpdate();

			rowInserted = preparedStatement.executeUpdate() > 0;

			preparedStatement.close();
//	        disconnect();
		}
		
		
		return rowInserted;
	}

	public ArrayList<YoutubeVideo> getAllVideos() throws SQLException {
		
		connect_func();
		
		ArrayList<YoutubeVideo> returnList = new ArrayList<YoutubeVideo>();
		YoutubeVideo video = new YoutubeVideo();
		
		String sql = "SELECT * FROM youtubevideos;";
		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
		
		// Get results
		ResultSet resultSet = preparedStatement.executeQuery();
    	
		while(resultSet.next()) {
			
			video = new YoutubeVideo();
    		
    		// Get info of this video
    		video.setUrl(resultSet.getString("url"));
			video.setTitle(resultSet.getString("title"));
			video.setDescription(resultSet.getString("description"));
			video.setTags(resultSet.getString("tags"));
			video.setPostuser(resultSet.getString("postuser"));
			video.setPostdate(resultSet.getString("postdate"));
			video.setComid(resultSet.getInt("comid"));
    		
			System.out.println("Added video " + video.getUrl());
			// Add this video to list
			returnList.add(video);
    	
    	}
    	
		
    	return returnList;
	}
	
	public YoutubeVideo getVideoFromURL(String url) throws SQLException {
		
		
		connect_func();
		YoutubeVideo video = new YoutubeVideo();
		String sql = "SELECT * FROM youtubevideos WHERE url = ?";
    	preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
    	
    	preparedStatement.setString(1, url);
    	
    	ResultSet resultSet = preparedStatement.executeQuery();
    	
    	if (resultSet.next()) {
    		video.setUrl(url);
			video.setTitle(resultSet.getString("title"));
			video.setDescription(resultSet.getString("description"));
			video.setTags(resultSet.getString("tags"));
			video.setPostuser(resultSet.getString("postuser"));
			video.setPostdate(resultSet.getString("postdate"));
			video.setComid(resultSet.getInt("comid"));
		}

		resultSet.close();
		//statement.close();
		
		return video;
	}

	public List<YoutubeTag> getTagsFromInput(String[] userInput) throws SQLException {
	
		List<YoutubeTag> returnTags = new ArrayList<YoutubeTag>();
		YoutubeTag temp = new YoutubeTag();
		String url;
		String tag;
		
		for(int i = 0; i < userInput.length; i++) {
			temp = new YoutubeTag();
			
			String sql = "SELECT distinct * FROM youtubetags where tag = ?;";
			
			preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
			
			preparedStatement.setString(1, userInput[i]);
			
			ResultSet resultSet = preparedStatement.executeQuery();
			
			if (resultSet.next()) {
				
				url = resultSet.getString(1);
				tag = resultSet.getString(2);
				
				temp.setTag(tag);
				temp.setUrl(url);
				
				returnTags.add(temp);
			}
			
			resultSet.close();
		}
		
		return returnTags;
	}
		
	
	
	public List<Comedian> getComedianFromInput(String[] userInput) throws SQLException {
		
		List<Comedian> returnComedian = new ArrayList<Comedian>();
		Comedian temp = new Comedian();
		connect_func();
		int comid;
		String firstname;
		String lastname;
		String birthday;
		String birthplace;
		
		for(int i = 0; i < userInput.length; i++) {
			
			temp = new Comedian();
			
			String sql = "SELECT distinct * FROM comedians WHERE firstname = ? OR lastname = ?";
			
			preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
			
			preparedStatement.setString(1, userInput[i]);
			preparedStatement.setString(2, userInput[i]);
			
			ResultSet resultSet = preparedStatement.executeQuery();
			
			if (resultSet.next()) {
				comid = resultSet.getInt(1);
				firstname = resultSet.getString(2);
				lastname = resultSet.getString(3);
				birthday = resultSet.getString(4);
				birthplace = resultSet.getString(5);
				
				
				
				temp.setComid(comid);
				temp.setFirstname(firstname);
				temp.setLastname(lastname);
				temp.setBirthday(birthday);
				temp.setBirthplace(birthplace);
				returnComedian.add(temp);
	
				
				
				}

			resultSet.close();
			
			}// END FOR
	
		
		return returnComedian;
	}
	
	
	public Comedian getComedianFromComid(int comid) throws SQLException{
		
		Comedian returnComedian = new Comedian();
		connect_func();
		
		String sql = "SELECT * FROM comedians WHERE comid = ?;";
		
		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);	
		
		preparedStatement.setInt(1, comid);
		
		ResultSet resultSet = preparedStatement.executeQuery();
		
		while(resultSet.next()) {
			String firstname = resultSet.getString("firstname");
			String lastname = resultSet.getString("lastname");
			String birthplace = resultSet.getString("birthplace");
			String birthday = resultSet.getString("birthday");
			
			// Create Object from queried data
			returnComedian.setComid(comid);
			returnComedian.setFirstname(firstname);
			returnComedian.setLastname(lastname);
			returnComedian.setBirthplace(birthplace);
			returnComedian.setBirthday(birthday);


		}
		
		
		
		return returnComedian;
	}
	
	public List<YoutubeVideo> relateComidToURL(List<Comedian> comedianList)  throws SQLException{
		
		connect_func();
		List<YoutubeVideo> videoList = new ArrayList<YoutubeVideo>();
		
		
		for(int i = 0; i < comedianList.size(); i++) {
		
			
			YoutubeVideo temp  = new YoutubeVideo();
			String sql = "SELECT * FROM youtubevideos WHERE comid = ?;";
			preparedStatement = (PreparedStatement) connect.prepareStatement(sql);	
			preparedStatement.setInt(1, comedianList.get(i).getComid());
			ResultSet resultSet = preparedStatement.executeQuery();
			
			
			while (resultSet.next()) {
				
				temp = new YoutubeVideo();
				String url = resultSet.getString("url");
				String title = resultSet.getString("title");
				String description = resultSet.getString("description");
				String postuser = resultSet.getString("postuser");
				String postdate = resultSet.getString("postdate");
				String tags = resultSet.getString("tags");
				int comid = resultSet.getInt("comid");
				
				temp.setUrl(url);
				temp.setTitle(title);
				temp.setDescription(description);
				temp.setPostuser(postuser);
				temp.setPostdate(postdate);
				temp.setTags(tags);
				temp.setComid(comid);

				// Create object from queried data
				videoList.add(temp);
			}
			
			resultSet.close();
			
			
			
		}
		
		
		
		return videoList;
	}
	
	public YoutubeVideo relateYoutubeIdToYoutubeVideo(String youtubeid) throws SQLException {
		
		connect_func();
		YoutubeVideo video = new YoutubeVideo();
		String sql = "SELECT * FROM youtubevideos WHERE url = ?;";
		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);	
		preparedStatement.setString(1, youtubeid);
		ResultSet resultSet = preparedStatement.executeQuery();
		
		while(resultSet.next()) {
			String url = resultSet.getString("url");
			String title = resultSet.getString("title");
			String description = resultSet.getString("description");
			String postuser = resultSet.getString("postuser");
			String postdate = resultSet.getString("postdate");
			String tags = resultSet.getString("tags");
			int comid = resultSet.getInt("comid");
			

			// Create object from queried data
			video = new YoutubeVideo(url, title, description, tags, comid, postuser, postdate);
		}
		
		return video;
	}

	
	// Method to return a list of youtubevideo objects given an array of tags
	public List<YoutubeVideo> relateTagsToURL(List<YoutubeTag> tagsFromInput) throws SQLException{
		
		
		connect_func();
		List<YoutubeVideo> videoList = new ArrayList<YoutubeVideo>();
		YoutubeVideo temp = new YoutubeVideo();
		
		for(int i = 0; i < tagsFromInput.size(); i++) {
		
			
			temp  = new YoutubeVideo();
			String sql = "SELECT * FROM youtubevideos WHERE tags = ?;";
			preparedStatement = (PreparedStatement) connect.prepareStatement(sql);	
			preparedStatement.setString(1, tagsFromInput.get(i).getTag());
			ResultSet resultSet = preparedStatement.executeQuery();
			
			
			while(resultSet.next()) {
				String url = resultSet.getString("url");
				String title = resultSet.getString("title");
				String description = resultSet.getString("description");
				String postuser = resultSet.getString("postuser");
				String postdate = resultSet.getString("postdate");
				String tags = resultSet.getString("tags");
				int comid = resultSet.getInt("comid");
				

				// Create object from queried data
				YoutubeVideo video = new YoutubeVideo(url, title, description, tags, comid, postuser, postdate);
				videoList.add(video);
				
				System.out.println("URL = " + url + " added from tag = " + tagsFromInput.get(i).getTag());
			}
			
			resultSet.close();
			
		}
		
		return videoList;
	}
		/*
		connect_func();
		List<YoutubeVideo> videoList = new ArrayList<YoutubeVideo>();
		
		for(int i = 0; i < userInput.length; i++)  {
			String sql = "SELECT distinct * FROM youtubevideos WHERE tags = ?";
		    
			preparedStatement = (PreparedStatement) connect.prepareStatement(sql);	
			preparedStatement.setString(1, userInput[i]);
			ResultSet resultSet = preparedStatement.executeQuery();
			
			

			if (resultSet.next()) {
				String url = resultSet.getString("url");
				String title = resultSet.getString("title");
				String description = resultSet.getString("description");
				String postuser = resultSet.getString("postuser");
				String postdate = resultSet.getString("postdate");
				String tags = resultSet.getString("tags");
				int comid = resultSet.getInt("comid");
				
				System.out.println("URL ADDED = " + url);

				// Create object from queried data
				YoutubeVideo video = new YoutubeVideo(url, title, description, tags, comid, postuser, postdate);
				videoList.add(video);
			}
			
			resultSet.close();
			
		}
			//statement.close();
			
			return videoList;
		}
		*/
	
	// Method to return tags from youtubetags
	public List<String> getTagsFromArray(String[] userInput) throws SQLException {
		connect_func();
		List<String> tagList = new ArrayList<String>();
		int count = 0;
		
		for(int i = 0; i < userInput.length; i++) {
			String sql = "SELECT tag FROM youtubetags WHERE tag = ?";
		    

			preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
			
			preparedStatement.setString(1, userInput[i]);

			ResultSet resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				tagList.add(resultSet.getString(1));
				
			}

			resultSet.close();
			//statement.close();
		}
		;
		return tagList;
		
	}
	

	
	// Method to return the comid of a comedian
	public Integer getComidFromSpecificComedian(String comedian) throws SQLException {
		
		Integer id = 0;
		connect_func();
		
		
		// Split first and last names
    	String[] comedianName = comedian.split(" ", 2);
    	String comedianFirstname = comedianName[0];
    	String comedianLastname = comedianName[1];
    	
    	// Grab comid from database
    	String sql = "SELECT comid FROM comedians WHERE firstname = ? AND lastname = ?";
    

		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
		
		preparedStatement.setString(1, comedianFirstname);
		preparedStatement.setString(2, comedianLastname);

		ResultSet resultSet = preparedStatement.executeQuery();

		if (resultSet.next()) {
			id = resultSet.getInt(1);
		}

		resultSet.close();
		//statement.close();
		
		return id;
		
		
	}
	
	// Method to insert a user into the table [Complete]
	public boolean insert(People people) throws SQLException {
		connect_func();
		String sql = "insert into user(email, password, passwordConfirmed, firstname, lastname, age) values (?,?,?,?,?,?)";

		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
		preparedStatement.setString(1, people.email);
		preparedStatement.setString(2, people.password);
		preparedStatement.setString(3, people.passwordConfirmed);
		preparedStatement.setString(4, people.firstname);
		preparedStatement.setString(5, people.lastname);
		preparedStatement.setInt(6, people.age);
//		preparedStatement.executeUpdate();

		boolean rowInserted = preparedStatement.executeUpdate() > 0;
		preparedStatement.close();
//        disconnect();
		return rowInserted;
	}

	// Method to delete a user from the table [Complete]
	public boolean delete(String email) throws SQLException {

		String sql = "DELETE FROM user WHERE email = ?";
		connect_func();

		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
		preparedStatement.setString(1, email);

		boolean rowDeleted = preparedStatement.executeUpdate() > 0;
		preparedStatement.close();
//        disconnect();
		return rowDeleted;
	}

	
	public ArrayList<Comedian> getComediansFromComidList(List<Integer> comidList) throws SQLException {
		
		connect_func();
		ArrayList<Comedian> comedianList = new ArrayList<Comedian>();
		String firstname;
		String lastname;
		String birthday;
		String birthplace;
		int comid;
		
		// Iterate over list of comid
		for(int i = 0; i < comidList.size(); i++) {
			
			int thisComid = comidList.get(i);
			System.out.println("Checking comid " + thisComid);
			
			String sql = "SELECT * FROM comedians WHERE comid =?;";
			preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
			preparedStatement.setInt(1, thisComid);
			
			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				Comedian temp = new Comedian();
				firstname = resultSet.getString("firstname");
				lastname = resultSet.getString("lastname");
				birthday = resultSet.getString("birthday");
				birthplace = resultSet.getString("birthplace");
				temp.setComid(thisComid);
				temp.setFirstname(firstname);
				temp.setLastname(lastname);
				temp.setBirthday(birthday);
				temp.setBirthplace(birthplace);
				comedianList.add(temp);
			}
			
			resultSet.close();
			
		}
		
		return comedianList;
	}
	
	
	
	public List<Integer> getComidFromFavorites(String email) throws SQLException {
		
		connect_func();
		List<Integer> comidList = new ArrayList<>();
		
		String sql = "SELECT * FROM isfavorite WHERE email =?;";
		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
		preparedStatement.setString(1, email);
		
		
		ResultSet resultSet = preparedStatement.executeQuery();
		int temp = 0;

		while (resultSet.next()) {
			temp = resultSet.getInt("comid");
			
			System.out.println("Favorite comid found = " + temp);
			comidList.add(temp);
		}
		
		resultSet.close();
		return comidList;
		
	}
	
	public List<Comedian> getComedianFromComid(List<Integer> comid) throws SQLException {
		
		
		 String sql = "select distinct * from comedians where comid = ?";
		 
		connect_func();
		
		List<Comedian> returnComedian = new ArrayList<Comedian>();
		Comedian tempComedian = new Comedian();
		
		for(int i = 0; i < comid.size(); i++) {
			preparedStatement = (PreparedStatement) connect.prepareStatement(sql);

			preparedStatement.setInt(1, comid.get(i));
			
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				
				tempComedian.comid = resultSet.getInt(1);
				tempComedian.firstname = resultSet.getString(2);
				tempComedian.lastname = resultSet.getString(3);
				tempComedian.birthday = resultSet.getString(4);
				tempComedian.birthplace = resultSet.getString(5);
				returnComedian.add(tempComedian);
				System.out.println("Comedian added = " + tempComedian.firstname + " " + tempComedian.lastname);
			}
			
			resultSet.close();
		}
		
		
		return returnComedian;
		
	}
	
	public boolean update(People people) throws SQLException {
		String sql = "update user set email = ?, password=?, passwordConfirmed=?, firstname=?, lastname=?, age=? where email = ?";
		connect_func();

		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);

		preparedStatement.setString(1, people.email);
		preparedStatement.setString(2, people.password);
		preparedStatement.setString(3, people.passwordConfirmed);
		preparedStatement.setString(4, people.firstname);
		preparedStatement.setString(5, people.lastname);
		preparedStatement.setInt(6, people.age);
		preparedStatement.setString(7, people.email);

		boolean rowUpdated = preparedStatement.executeUpdate() > 0;
		preparedStatement.close();
//        disconnect();
		return rowUpdated;
	}

	public People getPeople(String email) throws SQLException {

		People people = new People();
		String sql = "SELECT * FROM user WHERE email = ?";

		connect_func();

		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
		preparedStatement.setString(1, email);

		ResultSet resultSet = preparedStatement.executeQuery();

		if (resultSet.next()) {
			String password = resultSet.getString("password");
			String passwordConfirmed = resultSet.getString("passwordConfirmed");
			String firstname = resultSet.getString("firstname");
			String lastname = resultSet.getString("lastname");
			int age = Integer.parseInt(resultSet.getString("age"));

			people = new People(email, password, passwordConfirmed, firstname, lastname, age);
			
			System.out.println("PERSON CREATED = " + people.firstname);
		}

		resultSet.close();
		//statement.close();

		return people;
	}
	
	
	
	// NEW
	
	public boolean insertReview(String remark, char rating, String youtubeid, String currentUser) throws SQLException {
		connect_func();
		int reviewid = 0;
		
		
		
		try{
		// Get reviewid
			String getId = "select count(*) FROM reviews";
		
			statement = connect.createStatement();
			resultSet = statement.executeQuery("select count(*) from reviews;");
			
			while (resultSet.next()) {
				 reviewid = resultSet.getInt(1) + 1;
				 }
		}
		catch(NullPointerException e) {
			reviewid = 0;
		}
		
		String author = "";
		
		// Get author
		String getAuthor = "select postuser from youtubevideos where url = ?;";
		

		preparedStatement = (PreparedStatement) connect.prepareStatement(getAuthor);
		
		preparedStatement.setString(1, youtubeid);

		ResultSet resultSet = preparedStatement.executeQuery();

		if (resultSet.next()) {
			author = resultSet.getString(1);
		}

		resultSet.close();
		
		
		String sql = "insert into reviews(reviewid, remark, rating, author, youtubeid) values (?,?,?,?,?)";

		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
		preparedStatement.setInt(1, reviewid);
		preparedStatement.setString(2, remark);
		preparedStatement.setString(3, rating + " ");
		preparedStatement.setString(4, currentUser);
		preparedStatement.setString(5, youtubeid);


		// preparedStatement.executeUpdate();
		preparedStatement.executeUpdate();
		preparedStatement.close();
//		        disconnect();
		return true;
		}

		// Method to delete review

		public boolean deleteReview(int reviewid) throws SQLException {

		String sql = "DELETE FROM reviews WHERE reviewid = ?";
		connect_func();

		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
		preparedStatement.setInt(1, reviewid);

		boolean rowDeleted = preparedStatement.executeUpdate() > 0;
		preparedStatement.close();
//		        disconnect();
		return rowDeleted;
		}

		// Method to add comedian to favorites

		public boolean insertFavorite(int comid, String email) throws SQLException {
		connect_func();
		
		String postuser = email;
		
		String sql = "insert into isfavorite(email, comid) values (?,?)";

		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
		preparedStatement.setString(1, postuser);
		preparedStatement.setInt(2, comid);

		// preparedStatement.executeUpdate();
		boolean rowInserted = preparedStatement.executeUpdate() > 0;
		preparedStatement.close();
//		        disconnect();
		
		System.out.println("Comedian(" + comid + ") added to " + email + " favorites!");
		return rowInserted;
		}

		public boolean deleteFavorite(String email, int comid) throws SQLException {

		String sql = "DELETE FROM isFavorite WHERE email = ? AND comid = ?";
		connect_func();

		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
		preparedStatement.setString(1, email);
		preparedStatement.setInt(2, comid);
		
		

		boolean rowDeleted = preparedStatement.executeUpdate() > 0;
		preparedStatement.close();
//		        disconnect();
		return rowDeleted;
		}
		

		// Get Cool Comedians
		public ArrayList<Comedian> getCoolComedians() throws SQLException {
			
			connect_func();
			
			ArrayList<Comedian> returnList = new ArrayList<Comedian>();
			Comedian comedian = new Comedian();
			
			// NOTE: this query does not work properly
			String sql = "SELECT DISTINCT comedians.comid, firstname, lastname, birthday, birthplace\r\n" + 
					"FROM comedians \r\n" + 
					"INNER JOIN youtubevideos ON comedians.comid = youtubevideos.comid \r\n" + 
					"INNER JOIN reviews on youtubevideos.url = reviews.youtubeid\r\n" + 
					"WHERE reviews.rating = 'E' \r\n" + ";";
			
			
			preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
			
			// Get results
			ResultSet resultSet = preparedStatement.executeQuery();
	    	
			while(resultSet.next()) {
				
				comedian = new Comedian();
	    		
	    		// Get info of this comedian
				comedian.setComid(resultSet.getInt("comid"));
				comedian.setFirstname(resultSet.getString("firstname"));
				comedian.setLastname(resultSet.getString("lastname"));
				comedian.setBirthday(resultSet.getString("birthday"));
				comedian.setBirthplace(resultSet.getString("birthplace"));
	    		
				// Add this video to list
				returnList.add(comedian);
	    	
	    	}
	    	
			
	    	return returnList;
		}
		
		
		// Get new comedians (posted today for the first time)
		public List<Integer> getNewComedians() throws SQLException {
		
			connect_func();
			
			List<Integer> comidList = new ArrayList<Integer>();
			int currentComid = 0;
			
			String sql = "SELECT DISTINCT comedians.comid FROM comedians LEFT JOIN youtubevideos ON comedians.comid = youtubevideos.comid "
					+ "WHERE postdate = CURDATE() AND comedians.comid NOT IN"
					+ "(SELECT DISTINCT comedians.comid FROM comedians "
					+ "LEFT JOIN youtubevideos ON comedians.comid = youtubevideos.comid WHERE postdate < CURDATE())"
					+ "ORDER BY comedians.comid;";

			
			
			preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
			
			// Get results
			ResultSet resultSet = preparedStatement.executeQuery();
	    	
			while(resultSet.next()) {
				
	
	    		
	    		// Get info of this comedian
				currentComid = resultSet.getInt("comid");
				
	    		
				// Add this video to list
				comidList.add(currentComid);
	    	
	    	}
	    	
			
	    	return comidList;
		}
		
		
		
		public List<Comedian> getHotComedians() throws SQLException{
			
			connect_func();
			
			ArrayList<Comedian> returnList = new ArrayList<Comedian>();
			Comedian comedian = new Comedian();
			
			String sql = "SELECT C.comid, C.birthday, C.birthplace, C.firstname, C.lastname, COUNT(R.reviewid) AS NumberOfReviews FROM comedians C, youtubevideos Y, Reviews R "
					+ "WHERE Y.url=R.youtubeid AND C.comid=Y.comid GROUP BY R.youtubeid ORDER BY NumberOfReviews DESC LIMIT 3;";
			
			
			preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
			
			// Get results
			ResultSet resultSet = preparedStatement.executeQuery();
	    	
			while(resultSet.next()) {
				
	
				comedian = new Comedian();
	    		
	    		// Get info of this comedian
				comedian.setComid(resultSet.getInt("comid"));
				comedian.setFirstname(resultSet.getString("firstname"));
				comedian.setLastname(resultSet.getString("lastname"));
				comedian.setBirthday(resultSet.getString("birthday"));
				comedian.setBirthplace(resultSet.getString("birthplace"));
	    		
				// Add this video to list
				returnList.add(comedian);
	    		
	    	
	    	}
	    	
			
	    	return returnList;
			
			
			
			
		}
		
		public List<Comedian> getTopComedians() throws SQLException{
			connect_func();
			
			ArrayList<Comedian> returnList = new ArrayList<Comedian>();
			Comedian comedian = new Comedian();
			
			String sql = "SELECT c.comid, c.firstname, c.lastname, c.birthday, c.birthplace, count(y.url) as videoCount"
				+	" FROM comedians C INNER JOIN youtubevideos Y ON Y.comid = C.comid GROUP BY c.comid "
				+ "HAVING videoCount = (SELECT MAX(videoCount) FROM (SELECT count(y.url) as videoCount FROM comedians C "
				+ "INNER JOIN youtubevideos Y ON Y.comid = C.comid GROUP BY c.comid) as table1);";
			
			
			preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
			
			// Get results
			ResultSet resultSet = preparedStatement.executeQuery();
	    	
			while(resultSet.next()) {
				
	
				comedian = new Comedian();
	    		
	    		// Get info of this comedian
				comedian.setComid(resultSet.getInt("comid"));
				comedian.setFirstname(resultSet.getString("firstname"));
				comedian.setLastname(resultSet.getString("lastname"));
				comedian.setBirthday(resultSet.getString("birthday"));
				comedian.setBirthplace(resultSet.getString("birthplace"));
	    		
				// Add this video to list
				returnList.add(comedian);
	    		
	    	
	    	}
	    	
			
	    	return returnList;
			
		}
		
		
		
		public List<String> getAllTags() throws SQLException {
			
			connect_func();
			List<String> returnList = new ArrayList<String>();
			
			
			String sql = "SELECT * FROM youtubetags WHERE tag IS NOT NULL OR tag != '';";
				
				
			preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
				
			// Get results
			ResultSet resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				
				
				returnList.add(resultSet.getString("tag"));
			
				
			}
			
			
			
			
			return returnList;
			
		}
		
		
public List<People> getAllUsers() throws SQLException {
			
			connect_func();
			List<People> returnList = new ArrayList<People>();
			
			
			String sql = "SELECT * FROM user";
			String email;
			String firstname;
			String lastname;
			String password;
			String passwordConfirmed;
			int age;
				
				
			preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
				
			// Get results
			ResultSet resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				People people = new People();
				
				email = resultSet.getString("email");
				firstname = resultSet.getString("firstname");
				lastname = resultSet.getString("lastname");
				password = resultSet.getString("password");
				passwordConfirmed = resultSet.getString("passwordConfirmed");
				age = resultSet.getInt("age");
				
				people.setEmail(email);
				people.setAge(age);
				people.setFirstname(firstname);
				people.setLastname(lastname);
				people.setPassword(password);
				people.setPasswordConfirmed(passwordConfirmed);
				
				returnList.add(people);
				
			}
			
			
			
			
			return returnList;
			
		}
		
		
public List<IsFavorite> getFavoriteComedians(People user) throws SQLException {	
		
	List<IsFavorite> returnList = new ArrayList<IsFavorite>();
	
	
	connect_func();
	
	String email = user.getEmail();
	int comid;

	
	String sql = "SELECT * FROM isfavorite WHERE email = ?";
	preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
	
	preparedStatement.setString(1, email);
	
	ResultSet resultSet = preparedStatement.executeQuery();
	
	while(resultSet.next()) {
		IsFavorite temp = new IsFavorite();
		
		email = resultSet.getString("email");
		comid = resultSet.getInt("comid");
		
		temp.setComid(comid);
		temp.setEmail(email);
		
		returnList.add(temp);
		
	}
	
	
	
	
	return returnList;
}
		

	public List<People> getProductiveUsers() throws SQLException{
		
		
		
		List<People> productiveUsers = new ArrayList<People>();
		connect_func();
	
		
		String sql = "SELECT U.email, U.firstname, U.lastname, U.password, U.passwordConfirmed, U.age, count(Y.url) as videoCount "
				+ "FROM user U INNER JOIN youtubevideos Y ON Y.postuser = U.email GROUP BY U.email "
				+ "HAVING videoCount = (SELECT MAX(videoCount) FROM (SELECT count(Y.url) as videoCount FROM user U  "
				+ "INNER JOIN youtubevideos Y ON Y.postuser = U.email GROUP BY U.email) as table1);";
		
		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
	
		
		ResultSet resultSet = preparedStatement.executeQuery();
		
		String email;
		String firstname;
		String lastname;
		String password;
		String passwordConfirmed;
		int age;
		
		while(resultSet.next()) {
			People temp = new People();
			
			email = resultSet.getString("email");
			firstname = resultSet.getString("firstname");
			lastname = resultSet.getString("lastname");
			password = resultSet.getString("password");
			passwordConfirmed = resultSet.getString("passwordConfirmed");
			age = resultSet.getInt("age");
			
			temp.setAge(age);
			temp.setEmail(email);
			temp.setFirstname(firstname);
			temp.setLastname(lastname);
			temp.setPassword(password);
			temp.setPasswordConfirmed(passwordConfirmed);
			
			productiveUsers.add(temp);
			
		}
		
		
		
		
		return productiveUsers;
		
		
		
	}
	
	public List<YoutubeVideo> getVideosFromEmail(String email) throws SQLException{
		
		List<YoutubeVideo> returnList = new ArrayList<YoutubeVideo>();
		
		connect_func();
	
		
		String sql = "SELECT * FROM youtubevideos WHERE postuser = ?;";
		
		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
	
		preparedStatement.setString(1, email);
		
		ResultSet resultSet = preparedStatement.executeQuery();
		

		String postuser = email;
		String url;
		String title;
		String description;
		String tags;
		int comid;
		String postdate;
		
		while(resultSet.next()) {
			YoutubeVideo temp = new YoutubeVideo();
			url = resultSet.getString("url");
			title = resultSet.getString("title");
			description= resultSet.getString("description");
			tags = resultSet.getString("tags");
			postdate = resultSet.getString("postdate");
			comid = resultSet.getInt("comid");
			
			temp.setComid(comid);
			temp.setDescription(description);
			temp.setPostdate(postdate);
			temp.setPostuser(postuser);
			temp.setTags(tags);
			temp.setTitle(title);
			temp.setUrl(url);
			
			returnList.add(temp);
			
		}
		
		
		
		
		return returnList;
	
	}
	
	public List<String> getPositiveAuthors() throws SQLException{
		
		List<String> returnList = new ArrayList<String>();
		
		connect_func();
	
		
		String sql = "SELECT author FROM reviews WHERE rating = 'G' OR rating='E'"
				+ "AND author NOT IN (SELECT author FROM reviews WHERE rating = 'F' OR rating='P');";
		
		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
	
		
		ResultSet resultSet = preparedStatement.executeQuery();
		

		
		
		while(resultSet.next()) {
			String temp =  resultSet.getString("author");
			returnList.add(temp);
			
			
		}
		
	
		
		 /*
		 while(resultSet.next()) {
			People temp = new People();
			String email = resultSet.getString("email");
			String password = resultSet.getString("password");
			String passwordConfirmed = resultSet.getString("passwordConfirmed");
			String firstname = resultSet.getString("firstname");
			String lastname = resultSet.getString("lastname");
			int age = Integer.parseInt(resultSet.getString("age"));
			
			temp.setAge(age);
			temp.setEmail(email);
			temp.setFirstname(firstname);
			temp.setLastname(lastname);
			temp.setPassword(passwordConfirmed);
			temp.setPasswordConfirmed(passwordConfirmed);
			
			returnList.add(temp);
			*/
			
		
		 
		 
		
		return returnList;
		
	}
	
	
	
public List<People> getPositiveUsers(List<String> authors) throws SQLException{
		
		List<People> returnList = new ArrayList<People>();
		
		connect_func();
	
		for(int i = 0; i < authors.size(); i++) {
			String email = authors.get(i);
			

			
			String sql = "SELECT * FROM user WHERE email =?;";
			preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
			
			preparedStatement.setString(1, email);
			
			
			
			
			ResultSet resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				People temp = new People();
				email = resultSet.getString("email");
				String password = resultSet.getString("password");
				String passwordConfirmed = resultSet.getString("passwordConfirmed");
				String firstname = resultSet.getString("firstname");
				String lastname = resultSet.getString("lastname");
				int age = Integer.parseInt(resultSet.getString("age"));
				
				temp.setAge(age);
				temp.setPassword(password);
				temp.setEmail(email);
				temp.setFirstname(firstname);
				temp.setLastname(lastname);
				temp.setPassword(passwordConfirmed);
				temp.setPasswordConfirmed(passwordConfirmed);
				
				returnList.add(temp);
			
				}
		
		

	
			}// END FOR LOOP
		 
		 
		
		return returnList;
		
	}


	public List<YoutubeVideo> getPoorVideos() throws SQLException{
		
		List<YoutubeVideo> poorVideos = new ArrayList<YoutubeVideo>();
		
		connect_func();
	
		
			

			
			String sql = "SELECT url, title, description, postuser, postdate, tags, comid FROM youtubevideos INNER JOIN reviews ON youtubevideos.url = reviews.youtubeid "
					+ "WHERE rating = 'P' AND url NOT IN (SELECT  url FROM youtubevideos "
					+ "INNER JOIN reviews ON youtubevideos.url = reviews.youtubeid WHERE rating = 'F' OR rating='E' OR rating = 'G');";
			preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
			
			
			
			
			
			YoutubeVideo temp = new YoutubeVideo();
			ResultSet resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				temp = new YoutubeVideo();
				String url = resultSet.getString("url");
				String title = resultSet.getString("title");
				String description = resultSet.getString("description");
				String postuser = resultSet.getString("postuser");
				String postdate = resultSet.getString("postdate");
				String tags = resultSet.getString("tags");
				int comid = resultSet.getInt("comid");
				
				temp.setUrl(url);
				temp.setTitle(title);
				temp.setDescription(description);
				temp.setPostuser(postuser);
				temp.setPostdate(postdate);
				temp.setTags(tags);
				temp.setComid(comid);

				// Create object from queried data
				poorVideos.add(temp);
			
				}
		
		

	
		 
		 
		
		return poorVideos;
		
	}
	
	public List<IsFavorite> getAllFavorites() throws SQLException {
		
		List<IsFavorite> returnList = new ArrayList<IsFavorite>();
		
		connect_func();
		
		String sql = "SELECT * FROM isFavorite;";
				
		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
		
		IsFavorite temp = new IsFavorite();
		ResultSet resultSet = preparedStatement.executeQuery();
		
		while(resultSet.next()) {
			temp = new IsFavorite();
			
			int comid = resultSet.getInt("comid");
			String email = resultSet.getString("email");
			
			temp.setComid(comid);
			temp.setEmail(email);
		
			returnList.add(temp);
			}
	
		
		
		return returnList;
		
	}
		
}