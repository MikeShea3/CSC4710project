
public class Comedian {


	// Members
	protected int comid;
	protected String firstname;
	protected String lastname;
	protected String birthday;
	protected String birthplace;
	
	 // Methods
	
	// Default Constructor
    public Comedian() {
    	
    }
    
    // New Constructor
    public Comedian(int comid, String firstname, String lastname, String birthday, String birthplace) {
    	this.comid = comid;
    	this.firstname = firstname;
    	this.lastname = lastname;
    	this.birthday = birthday;
    	this.birthplace = birthplace;
    }

	public int getComid() {
		return comid;
	}

	public void setComid(int comid) {
		this.comid = comid;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getBirthplace() {
		return birthplace;
	}

	public void setBirthplace(String birthplace) {
		this.birthplace = birthplace;
	}
    
    
}
