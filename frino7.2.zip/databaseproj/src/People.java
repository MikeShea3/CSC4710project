public class People {
    
    // New Data
    protected String email;
    protected String password;
    protected String passwordConfirmed;
    protected String firstname;
    protected String lastname;
    protected int age;
  
 
    // Methods
    public People() {
    }
    
    // New Constructor
    public People(String email, String password, String passwordConfirmed, String firstname, String lastname, int age) {
    	this.email = email;
    	this.password = password;
    	this.passwordConfirmed = passwordConfirmed;
    	this.firstname = firstname;
    	this.lastname = lastname;
    	this.age = age;
    }
    
    // Getters and Setters
    public void setEmail(String email) {
    	this.email = email;
    }
    
    public String getEmail() {
    	return this.email;
    }
    
    public void setPassword(String password) {
    	this.password = password;
    }
    
    public String getPassword() {
    	return this.password;
    }
    
    public void setPasswordConfirmed(String passwordConfirmed) {
    	this.passwordConfirmed = passwordConfirmed;
    }
    
    public String getPasswordConfirmed() {
    	return this.passwordConfirmed;
    }
    
    public void setFirstname(String firstname) {
    	this.firstname = firstname;
    }
    
    public String getFirstname() {
    	return this.firstname;
    }
    
    public void setLastname(String lastname) {
    	this.lastname = lastname;
    }
    
    public String getLastname() {
    	return this.lastname;
    }
    
    public void setAge(int age) {
    	this.age = age;
    }
    
    public Integer getAge() {
    	return this.age;
    }
}
    
    
    