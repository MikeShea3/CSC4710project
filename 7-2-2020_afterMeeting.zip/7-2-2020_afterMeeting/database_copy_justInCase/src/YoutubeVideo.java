
public class YoutubeVideo {

	protected String url;
	protected String title;
	protected String description;
	protected int comid;
	protected String postuser;
	protected String postdate;
	
	// Default Constructor
	public YoutubeVideo() {
		
	}
	
	// Arg Constructor
	public YoutubeVideo(String url, String title, String description, int comid, String postuser, String postdate) {
		
		this.url = url;
		this.title = title;
		this.description = description;
		this.comid = comid;
		this.postuser = postuser;
		this.postdate = postdate;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getComid() {
		return comid;
	}

	public void setComid(int comid) {
		this.comid = comid;
	}

	public String getPostuser() {
		return postuser;
	}

	public void setPostuser(String postuser) {
		this.postuser = postuser;
	}

	public String getPostdate() {
		return postdate;
	}

	public void setPostdate(String postdate) {
		this.postdate = postdate;
	}
	
	
	
}
